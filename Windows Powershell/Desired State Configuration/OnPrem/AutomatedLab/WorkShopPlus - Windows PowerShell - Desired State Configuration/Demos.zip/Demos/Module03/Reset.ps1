#Requires -RunAsAdministrator 
#Requires -Version 4
Clear-Host 
$CurrentDir = Split-Path -Path $MyInvocation.MyCommand.Path -Parent

Set-Location -Path $CurrentDir

Uninstall-WindowsFeature -Name Windows-Server-Backup -ComputerName ms1

Install-WindowsFeature Web-Scripting-Tools
Get-WebSite -Name PSDSC* | Remove-Website
Remove-WindowsFeature -Name Web-Server, ManagementOData, DSC-Service
Get-ChildItem -Path c:\inetpub -File -Recurse | Remove-Item -Force -Confirm:$false

Remove-Item C:\Windows\System32\Configuration\Current.mof, C:\Windows\System32\Configuration\backup.mof, C:\Windows\System32\Configuration\Previous.mof -ErrorAction SilentlyContinue
Get-ChildItem -Path 'C:\Program Files\WindowsPowerShell\DSCService\' | Remove-Item -Recurse -Force -Confirm:$false

Restart-Computer

#Requires -RunAsAdministrator 
#Requires -Version 4
Clear-Host 
$CurrentDir = Split-Path -Path $MyInvocation.MyCommand.Path -Parent
#$CurrentDir="C:PShellDemos\Module03"

Set-Location -Path $CurrentDir

# Set the config target to PULL mode.
# We assign the GUID to the remote target.
[DscLocalConfigurationManager()]
Configuration LCMPullv5
{
	Param (
		$ComputerName,
		$GUID
	)
	Node $ComputerName
	{
		Settings
		{
			ActionAfterReboot              = 'ContinueConfiguration'
			AllowModuleOverWrite           = $True
			ConfigurationID                = $GUID
			ConfigurationMode              = 'ApplyAndMonitor'
			ConfigurationModeFrequencyMins = 15
			RefreshFrequencyMins           = 30
			StatusRetentionTimeInDays      = 7
			RebootNodeIfNeeded             = $True
			RefreshMode                    = 'Pull'
		}
		ConfigurationRepositoryWeb PullServer
		{
			ServerURL                = 'http://pull.contoso.com:8080/PSDSCPullServer.svc'
			AllowUnsecureConnection  = $True
		}
	}
}
LCMPullv5 -ComputerName ms1.contoso.com, ms2.contoso.com -GUID $GUID

# Connect to node
$cim = New-CimSession -ComputerName ms1.contoso.com, ms2.contoso.com

# Configure LCM
Set-DscLocalConfigurationManager -Path .\LCMPullv5 -CimSession $cim

# Confirm LCM
Get-DscLocalConfigurationManager -CimSession $cim
(Get-DscLocalConfigurationManager -CimSession $cim).ConfigurationDownloadManagers

# Trigger pull of configuration (~45 seconds)
Update-DscConfiguration -CimSession $cim -Wait -Verbose

# Verify that Windows Server Backup is installed
Get-WindowsFeature -Name Windows-Server-Backup -ComputerName ms1
Get-WindowsFeature -Name Windows-Server-Backup -ComputerName ms2

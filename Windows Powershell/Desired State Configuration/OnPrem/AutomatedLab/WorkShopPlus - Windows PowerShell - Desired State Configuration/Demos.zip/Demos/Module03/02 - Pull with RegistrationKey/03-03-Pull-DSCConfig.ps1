﻿#Requires -RunAsAdministrator 
#Requires -Version 4
Clear-Host 
$CurrentDir = Split-Path -Path $MyInvocation.MyCommand.Path -Parent
#$CurrentDir="C:PShellDemos\Module03"

Set-Location -Path $CurrentDir

[DSCLocalConfigurationManager()]
configuration PullClientRegKey
{
	Node @('ms1','ms2')
	{
		Settings
		{
			RefreshMode = 'Pull'
			RefreshFrequencyMins = 30 
			RebootNodeIfNeeded = $true
		}
		ConfigurationRepositoryWeb PullServer
		{
			ServerURL = 'http://PULL.contoso.com:8080/PSDSCPullServer.svc'
			RegistrationKey = $RegKey
			ConfigurationNames = @($ConfigName)
			AllowUnsecureConnection = $true
		}      
	}
}
# Generating the LCM MOF file(s)
PullClientRegKey

# Getting the LCM Configuration on the targeted nodes
Get-DscLocalConfigurationManager -CimSession ms1,ms2

# Setting the LCM Configuration on the targeted nodes
Set-DscLocalConfigurationManager -Path .\PullClientRegKey -Verbose -CimSession ms1
Set-DscLocalConfigurationManager -Path .\PullClientRegKey -Verbose -CimSession ms2

# Getting the LCM Configuration on the targeted nodes
Get-DscLocalConfigurationManager -CimSession ms1,ms2
(Get-DscLocalConfigurationManager -CimSession ms1,ms2).ConfigurationDownloadManagers

# Forcing the configuration to refresh
Update-DscConfiguration -CimSession ms1 -Wait -Verbose
Update-DscConfiguration -CimSession ms2 -Wait -Verbose

# Testing if the path exists
Invoke-Command -ComputerName ms1,ms2 -ScriptBlock { Test-Path 'C:\MyTemp'}
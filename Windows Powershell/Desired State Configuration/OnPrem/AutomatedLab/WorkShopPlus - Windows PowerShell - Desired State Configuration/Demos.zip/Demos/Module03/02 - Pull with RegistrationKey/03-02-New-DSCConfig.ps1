﻿configuration PullTestConfig
{
	Import-DscResource -ModuleName 'PSDesiredStateConfiguration' 
    
	node localhost
	{
		File TempDir
		{
			Ensure          = 'Present'
			DestinationPath = 'C:\MyTemp'
			Type            = 'Directory'
		}       
	}
}

PullTestConfig
$ConfigName = "MyConfig"

#Copy-Item -Path .\PullTestConfig\localhost.mof -Destination "C:\Program Files\WindowsPowerShell\DscService\Configuration\$ConfigName.mof"
#New-DscChecksum "C:\Program Files\WindowsPowerShell\DscService\Configuration\$ConfigName.mof" -Force
Rename-Item -Path .\PullTestConfig\localhost.mof -NewName "$ConfigName.mof"
Import-Module xPSDesiredStateConfiguration
Publish-DSCModuleAndMof -Source .\PullTestConfig -Force

Get-ChildItem -Path 'C:\Program Files\WindowsPowerShell\DscService\Configuration\'

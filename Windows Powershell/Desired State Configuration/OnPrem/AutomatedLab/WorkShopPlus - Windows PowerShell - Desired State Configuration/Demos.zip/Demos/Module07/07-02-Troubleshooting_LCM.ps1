#Requires -RunAsAdministrator 
#Requires -Version 4
Clear-Host 
$CurrentDir = Split-Path -Path $MyInvocation.MyCommand.Path -Parent
#$CurrentDir="C:PShellDemos\Module07"

Set-Location -Path $CurrentDir

## Configuration Status

Get-DscConfiguration -CimSession $CS

# V5
Get-DscConfigurationStatus -CimSession $CS -OutVariable Status | Format-Table -AutoSize

$Status |
Select-Object -Property ResourcesInDesiredState, ResourcesNotInDesiredState |
Format-List

$Status |
ForEach-Object -MemberName ResourcesInDesiredState |
Out-GridView
$Status | ForEach-Object -MemberName ResourcesNotInDesiredState

Test-DscConfiguration -CimSession $CS
Test-DscConfiguration -CimSession $CS -Detailed
Test-DscConfiguration -CimSession $CS -Verbose


# Configuration Status

Get-DscConfigurationStatus -CimSession $CS -OutVariable Status -All

Invoke-Command -CN $CN -ScriptBlock {
	Get-DscConfigurationStatus -All
}

psEdit -filenames "\\$CN\c$\windows\System32\Configuration\DSCStatusHistory.mof"

Get-ChildItem -Path "\\$CN\c$\windows\System32\Configuration\ConfigurationStatus" -OutVariable $statusFiles

# Remove Meta Configurations
Get-ChildItem -Path "\\$CN\c$\windows\System32\Configuration"
Get-ChildItem -Path "\\$CN\c$\windows\System32\Configuration" -Filter meta*.mof

# Confirm the current setting in PULL mode
Get-DscLocalConfigurationManager -CimSession $CS 

# Reset the LCM
Remove-Item -Path "\\$CN\c$\windows\System32\Configuration\MetaConfig*.mof"

# Might take a second to refresh
# Confirm the setting are removed and it goes back to default PUSH
Get-DscLocalConfigurationManager -CimSession $CS 

# Use a helper function to set server back to PULL Mode.
#Import-Module -Name psdsc
#Start-DeployDSCLCMConfigPullSMB -ComputerName $CN

# likely want to utilize the Event Logs for better history tracking.
# This is covered in the next section.

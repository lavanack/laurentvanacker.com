#Requires -RunAsAdministrator 
#Requires -Version 4
Clear-Host 
$CurrentDir = Split-Path -Path $MyInvocation.MyCommand.Path -Parent
#$CurrentDir="C:PShellDemos\Module07"

Get-Command -Module PsDesiredStateConfiguration -Noun DscDebug

Get-Command Enable-DscDebug -Syntax
Get-Help -Name Enable-DscDebug -Full

Get-DscLocalConfigurationManager | Select-Object -Property DebugMode

Enable-DscDebug
# -BreakAll required (not reflected in help yet)

Get-DscLocalConfigurationManager | Select-Object -Property DebugMode

Enable-DscDebug -BreakAll

Get-DscLocalConfigurationManager | Select-Object -Property DebugMode

Enable-DscDebug -BreakAll -CimSession ms1

Get-DscLocalConfigurationManager -CimSession ms1 | Select-Object -Property DebugMode

Disable-DscDebug -CimSession pull, ms1

Get-DscLocalConfigurationManager -CimSession pull, ms1 | Select-Object -Property DebugMode

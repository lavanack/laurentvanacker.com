#Requires -RunAsAdministrator 
#Requires -Version 4
Clear-Host 
$CurrentDir = Split-Path -Path $MyInvocation.MyCommand.Path -Parent
#$CurrentDir="C:PShellDemos\Module07"

#To use TLS 1.2
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12

Set-Location -Path $CurrentDir

# xDscDiagnostics PowerShell Module
Find-Module -Name xDscDiagnostics -Repository PSGallery

Install-Module -Name xDscDiagnostics -Force -Verbose

Get-Command -Module xDscDiagnostics | Format-Table -AutoSize

Get-Command Update-xDscEventLogStatus -Syntax


Update-xDscEventLogStatus -ComputerName ms1 -Status Disabled -Channel Debug -Verbose
Update-xDscEventLogStatus -ComputerName ms1 -Status Disabled -Channel Analytic -Verbose

Update-xDscEventLogStatus -ComputerName ms1 -Status Enabled -Channel Debug -Verbose
Update-xDscEventLogStatus -ComputerName ms1 -Status Enabled -Channel Analytic -Verbose

# Listlog - IsEnabled = True
Get-WinEvent -cn ms1 -ListLog 'Microsoft-Windows-DSC/Debug' | Select-Object -Property *
Get-WinEvent -cn ms1 -ListLog 'Microsoft-Windows-DSC/Analytic'


#region Configuration
Configuration myDefaultConfig {
	param ( [string[]]$ComputerName = $env:COMPUTERNAME )

	Import-DSCResource -ModuleName PSDesiredStateConfiguration
  
	Node $ComputerName {
		File dsctestdir
		{
			DestinationPath = 'c:\dsctest'
			Type            = 'Directory'
		}
      
		File dsctestfile
		{
			DestinationPath = 'c:\dsctest\dsctest.txt'
			Contents        = "$($Node.Nodename) $(Get-Date)"
			Type            = 'File'
			DependsOn       = '[File]dsctestdir'
		}
	}#Node
}

myDefaultConfig -ComputerName ms1 -OutputPath .\myDefaultConfig

# Generate activity
Start-DscConfiguration -Path .\myDefaultConfig -ComputerName ms1 -Force -Wait -Verbose

# Create some logs in Debug
Get-DscLocalConfigurationManager -CimSession ms1

# View Events
Get-WinEvent -cn ms1 -LogName 'Microsoft-Windows-DSC/Debug' -Oldest

# Disable the Logs
Update-xDscEventLogStatus -ComputerName ms1 -Status Disabled -Channel Debug -Verbose
# Enable them again
Update-xDscEventLogStatus -ComputerName ms1 -Status Enabled -Channel Debug -Verbose

# note the logs are empty ?!
# View Events
Get-WinEvent -cn ms1 -LogName 'Microsoft-Windows-DSC/Debug' -Oldest

# Check the Analytic
Get-WinEvent -cn ms1 -LogName 'Microsoft-Windows-DSC/Analytic' -Oldest

#endregion

# Generate activity
Start-DscConfiguration -Path .\myDefaultConfig -ComputerName ms1 -Force -Wait -Verbose

# xDscDiagnostics PowerShell Module
Get-Command -Module xDscDiagnostics | Format-Table -AutoSize

Get-Command Get-xDscOperation -Syntax

$OP = Get-xDscOperation -Newest 5 -ComputerName ms1
$OP[3].jobid.guid

Get-Command Trace-xDscOperation -Syntax

Trace-xDscOperation -JobId ($op[3].jobid.guid) -ComputerName ms1 | Format-Table -AutoSize
Trace-xDscOperation -SequenceID 1 -ComputerName ms1 | Format-Table -AutoSize

Test-DscConfiguration -Detailed -CimSession ms1

Start-DscConfiguration -Path .\myDefaultConfig


#----------------------------------------------------------------------
$log     = 'Microsoft-Windows-DSC/Operational'
$MinFrom = 30
$Start   = (Get-Date).AddMinutes(-$MinFrom)
$End     = (Get-Date).AddMinutes(-0)
$Node    = 'ms1'
$Filter  = @{ LogName = $log ; StartTime = $Start ; EndTime   = $End }

Get-WinEvent -FilterHashtable $Filter -ComputerName $Node  | 
Sort-Object -Property TimeCreated |
Select-Object -Property @{n = "Jobid";e = {
		$_.properties[0].value
}} -Unique | 
Where-Object -FilterScript {
	$_.jobid -as [Guid]
} |
ForEach-Object -Process {
	Write-Verbose -Message "Processing JobID $($_.JobID)" -Verbose
	Trace-xDscOperation -JobId $_.jobID -ComputerName $Node -EA 0
} #---------------------------------------------------------------------

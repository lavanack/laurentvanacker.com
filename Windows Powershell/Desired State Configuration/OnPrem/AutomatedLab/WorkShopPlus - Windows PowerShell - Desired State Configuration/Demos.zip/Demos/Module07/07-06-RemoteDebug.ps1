﻿#Requires -RunAsAdministrator 
#Requires -Version 4
Clear-Host 
$CurrentDir = Split-Path -Path $MyInvocation.MyCommand.Path -Parent
#$CurrentDir="C:PShellDemos\Module07"

Set-Location -Path $CurrentDir

#requires -Version 4.0 -Modules PSDesiredStateConfiguration
### ResourceScriptBreakAll
### This demo is not working on April Preview


<#
		# Set LCM DebugMode to ResourceScriptBreakAll
		[DscLocalConfigurationManager()]
		Configuration ConfigureLCMForDebug
		{
		Node ms2
		{
		Settings
		{
		DebugMode = 'ResourceScriptBreakAll'
		}
		}
		}
		ConfigureLCMForDebug -outputpath c:\LCMDebug
		Set-DscLocalConfigurationManager -path c:\LCMDebug -verbose
#>

Enable-DscDebug -BreakAll -CimSession ms2

Get-DscLocalConfigurationManager -CimSession ms2 | Select-Object -Property DebugMode


# Send a configuration
Configuration myDefaultConfig {
	param ( [string[]]$ComputerName = $env:COMPUTERNAME )

	Import-DSCResource -ModuleName PSDesiredStateConfiguration
  
	Node $ComputerName {

		Group InfoSecBackDoor
		{
			GroupName   = 'InfoSec'
			Description = 'This is not the group you are looking for.'
			Ensure      = 'Present'
		}
	}
}

myDefaultConfig -ComputerName ms2 -OutputPath .\myDefaultConfig

Start-DscConfiguration -Path .\myDefaultConfig -Wait -Verbose -ComputerName ms2 -Force


#Requires -RunAsAdministrator 
#Requires -Version 4
Clear-Host 
$CurrentDir = Split-Path -Path $MyInvocation.MyCommand.Path -Parent
#$CurrentDir="C:PShellDemos\Module07"

Set-Location -Path $CurrentDir

## Reset LCM to push on all nodes
Invoke-Command -ComputerName ms1, ms2, pull -ScriptBlock {
	Remove-Item -Path C:\windows\system32\Configuration\current.mof
}

## Looking at the LCM and Configurations

$CN = 'ms1'
Test-WSMan -ComputerName $CN

$CS = New-CimSession -ComputerName $CN
$CS

# LCM
Get-DscLocalConfigurationManager -CimSession $CS

Get-ChildItem -Path "\\$CN\c$\windows\System32\Configuration"
Invoke-Command -ComputerName $CN -ScriptBlock {
	Get-ChildItem -Path c:\windows\System32\Configuration
}
Invoke-Command -ComputerName $CN -ScriptBlock {
	Get-ChildItem -Path C:\windows\System32\Configuration\ConfigurationStatus
}


# CIM

$CIM = @{ 
	Namespace   = 'root/Microsoft/Windows/DesiredStateConfiguration' 
	ClassName   = 'MSFT_DSCLocalConfigurationManager' 
	MethodName  = 'PerformRequiredConfigurationChecks' 
	Arguments   = @{Flags = [uint32]1}
	ErrorAction = 'Stop'
	Verbose     = $true
	ComputerName = 'ms1'
} 

Invoke-CimMethod @CIM


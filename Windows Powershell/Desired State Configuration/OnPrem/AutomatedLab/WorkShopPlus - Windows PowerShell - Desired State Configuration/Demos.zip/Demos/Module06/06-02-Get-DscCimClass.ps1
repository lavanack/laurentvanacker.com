#Requires -RunAsAdministrator 
#Requires -Version 4
Clear-Host 
$CurrentDir = Split-Path -Path $MyInvocation.MyCommand.Path -Parent
#$CurrentDir="C:PShellDemos\Module06"

#To use TLS 1.2
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12

Set-Location -Path $CurrentDir
Install-Module xPSDesiredStateConfiguration -Verbose

# All loaded DSC classes
Get-CimClass -Namespace 'root\Microsoft\Windows\DesiredStateConfiguration' | Sort-Object -Property CimClassName

# The xDSCWebService loaded to maintain the pull server configuration
Get-CimClass -Namespace 'root\Microsoft\Windows\DesiredStateConfiguration' -ClassName MSFT_xDSCWebService | Format-List -Property *

# Properties of that class
(Get-CimClass -Namespace 'root\Microsoft\Windows\DesiredStateConfiguration' -ClassName MSFT_xDSCWebService).CimClassProperties |
Sort-Object -Property Qualifiers, Name |
Format-Table -AutoSize

# Compare this with the resource MOF
Get-ChildItem -Path 'C:\Program Files\WindowsPowerShell\Modules\xPSDesiredStateConfiguration\' -Recurse -Filter MSFT_xDSCWebService.Schema.mof | ForEach-Object -Process {
	powershell_ise.exe $($_.FullName) 
}
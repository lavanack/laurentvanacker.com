#Requires -RunAsAdministrator 
#Requires -Version 4
Clear-Host 
$CurrentDir = Split-Path -Path $MyInvocation.MyCommand.Path -Parent
#$CurrentDir="C:PShellDemos\Module06"

#To use TLS 1.2
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12

Set-Location -Path $CurrentDir
Install-Module xPSDesiredStateConfiguration -Verbose

# Our earlier script-based resource module
Get-Module contosoClassResources -ListAvailable
Get-ChildItem -Path "$Env:PROGRAMFILES\WindowsPowerShell\Modules\contosoClassResources"

# Not yet published for pull
Get-ChildItem -Path "$Env:PROGRAMFILES\WindowsPowerShell\DscService\Modules\cont*"

# Publish it
Publish-DSCModuleAndMof -Source "$Env:PROGRAMFILES\WindowsPowerShell\Modules\cont*" -Verbose
Get-ChildItem -Path "$Env:PROGRAMFILES\WindowsPowerShell\DscService\Modules\cont*"

#endregion



#region  Publish configuration

configuration ContosoResourceTest
{
Param ($ComputerName)

    Import-DscResource -ModuleName contosoClassResources

    Node $ComputerName
    {
        FileTextResource TestTextFile
        {
           Ensure = 'Present'
           Path = 'C:\DropZone\Sample.txt'
           Value = @'
Simple text test.
Multiple line text.
'@
        }
    }
}

ContosoResourceTest -ComputerName ms1.contoso.com

$GUID = [guid]::NewGuid().Guid

$source = ".\ContosoResourceTest\ms1.contoso.com.mof"
$dest = "C:\Program Files\WindowsPowerShell\DSCService\Configuration\$guid.mof"
Copy-Item -Path $source -Destination $dest
New-DSCChecksum $dest -Force

Get-ChildItem "C:\Program Files\WindowsPowerShell\DSCService\Configuration\"

#region  Configure LCM on pull node

###
### LCM AllowModuleOverWrite must be set to true to pull new module version
###
[DscLocalConfigurationManager()]
Configuration LCMPullv5
{
Param (
    $ComputerName,
    $GUID
)
    Node $ComputerName
    {
        Settings
        {
            ActionAfterReboot              = 'ContinueConfiguration'
            AllowModuleOverWrite           = $True
            ConfigurationID                = $GUID
            ConfigurationMode              = 'ApplyAndMonitor'
            RebootNodeIfNeeded             = $True
            RefreshMode                    = 'Pull'
        }
        ConfigurationRepositoryWeb PullServer
        {
            ServerURL                = "https://pull.contoso.com/PSDSCPullServer.svc"
            AllowUnsecureConnection  = $true
        }
    }
}

LCMPullv5 -ComputerName ms1.contoso.com -GUID $GUID

# Note that the module is not present on the node
Invoke-Command -ComputerName ms1.contoso.com -ScriptBlock {Get-Module contosoClassResources -ListAvailable}

# Connect to node
$cim = New-CimSession -ComputerName ms1.contoso.com

# Configure LCM
Set-DSCLocalConfigurationManager -Path .\LCMPullv5 -CimSession $cim

# Confirm LCM
Get-DSCLocalConfigurationManager -CimSession $cim
(Get-DSCLocalConfigurationManager -CimSession $cim).ConfigurationDownloadManagers

# Trigger pull of configuration
Update-DscConfiguration -CimSession $cim -Wait -Verbose

# This forced the node to pull our new module
# Check the module version on the node
Invoke-Command -ComputerName ms1.contoso.com -ScriptBlock {Get-Module contosoClassResources -ListAvailable}

#endregion

#region  Edit the module and increment version

#Add line to Test method of the class FileResource
#    Write-Verbose " *** THIS IS MODULE VERSION NEXT *** "
powershell_ise.exe 'C:\Program Files\WindowsPowerShell\Modules\contosoClassResources\contosoClassResources.psm1'

#Incrementing version
notepad 'C:\Program Files\WindowsPowerShell\Modules\contosoClassResources\contosoClassResources.psd1'

#endregion



#region  Publish module v2

Get-Module contosoClassResources -ListAvailable

dir "$Env:PROGRAMFILES\WindowsPowerShell\DscService\Modules\cont*"

Publish-DSCModuleAndMof -Source "$Env:PROGRAMFILES\WindowsPowerShell\Modules\cont*" -Verbose

dir "$Env:PROGRAMFILES\WindowsPowerShell\DscService\Modules\cont*"

#endregion



#region  Must version configuration to trigger checksum change
# The module version in the build should be enough to trigger
# a new checksum.

configuration ContosoResourceTest
{
Param ($ComputerName)

    Import-DscResource -ModuleName contosoClassResources

    Node $ComputerName
    {
        FileTextResource TestTextFile
        {
           Ensure = 'Present'
           Path = 'C:\DropZone\Sample.txt'
           Value = @'
Simple text test.Multiple line text.
'@
        }
    }
}

ContosoResourceTest -ComputerName ms1.contoso.com

$source = ".\ContosoResourceTest\ms1.contoso.com.mof"
$dest = "C:\Program Files\WindowsPowerShell\DSCService\Configuration\$guid.mof"
Copy-Item -Path $source -Destination $dest

# FORCE new checksum to overwrite previous
New-DSCChecksum $dest -Force

# See new version in the MOF
notepad $dest

Get-ChildItem "C:\Program Files\WindowsPowerShell\DSCService\Configuration\"

# Trigger pull
# Notice the different checksum
Update-DscConfiguration -CimSession $cim -Wait -Verbose

# Check the module version on the node
Invoke-Command -ComputerName ms1.contoso.com -ScriptBlock {Get-Module contosoClassResources -ListAvailable}

#endregion



#region  Roll back the module

# Delete the current module version
Get-ChildItem "C:\Program Files\WindowsPowerShell\DSCService\Modules\contosoClassResources_1.1.zip*"
Remove-Item "C:\Program Files\WindowsPowerShell\DSCService\Modules\contosoClassResources_1.1.zip*"

# Must uninstall v1.1 module from target node
Invoke-Command -ComputerName ms1.contoso.com -ScriptBlock {Get-Module -Name contosoClassResources -ListAvailable | %{Remove-Item -Path $_.ModuleBase -Force -Recurse}}
Invoke-Command -ComputerName ms1.contoso.com -ScriptBlock {Get-Module contosoClassResources -ListAvailable}

# Notice that local module version is in the MOF
notepad $dest

# Must roll back local copy of module used to compile the MOF
#Remove line to Test method of the class FileResource
#    Write-Verbose " *** THIS IS MODULE VERSION NEXT *** "
powershell_ise.exe 'C:\Program Files\WindowsPowerShell\Modules\contosoClassResources\contosoClassResources.psm1'

#Decrementing version
notepad 'C:\Program Files\WindowsPowerShell\Modules\contosoClassResources\contosoClassResources.psd1'


#region  Publish module v2

Get-Module contosoClassResources -ListAvailable

dir "$Env:PROGRAMFILES\WindowsPowerShell\DscService\Modules\cont*"

Publish-DSCModuleAndMof -Source "$Env:PROGRAMFILES\WindowsPowerShell\Modules\cont*" -Verbose

dir "$Env:PROGRAMFILES\WindowsPowerShell\DscService\Modules\cont*"

#endregion


# Update the configuration
configuration ContosoResourceTest
{
Param ($ComputerName)

    Import-DscResource -ModuleName contosoClassResources

    Node $ComputerName
    {
        FileTextResource TestTextFile
        {
           Ensure = 'Present'
           Path = 'C:\DropZone\Sample.txt'
           Value = @'
Simple text test.
Multiple line text.
'@
        }
    }
}

ContosoResourceTest -ComputerName ms1.contoso.com

$source = ".\ContosoResourceTest\ms1.contoso.com.mof"
$dest = "C:\Program Files\WindowsPowerShell\DSCService\Configuration\$guid.mof"
Copy-Item -Path $source -Destination $dest

# FORCE new checksum to overwrite previous
New-DSCChecksum $dest -Force

Get-ChildItem "C:\Program Files\WindowsPowerShell\DSCService\Configuration\"

# Trigger pull
Update-DscConfiguration -CimSession $cim -Wait -Verbose

# Check the module version on the node
Invoke-Command -ComputerName ms1.contoso.com -ScriptBlock {Get-Module contosoClassResources -ListAvailable}


#endregion


Remove-CimSession $cim

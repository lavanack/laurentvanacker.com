#Requires -RunAsAdministrator 
#Requires -Version 4
Clear-Host 
$CurrentDir = Split-Path -Path $MyInvocation.MyCommand.Path -Parent
#$CurrentDir="C:PShellDemos\Module06"

#To use TLS 1.2
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12

Set-Location -Path $CurrentDir

# View the LCM configuration
Get-DscLocalConfigurationManager
Get-DscLocalConfigurationManager | Format-List -Property ConfigurationMode, RefreshMode, ActionAfterReboot, RebootNodeIfNeeded

# Configure the LCM outside of change control window
[DscLocalConfigurationManager()]
Configuration LCMv5
{
	Param (
		$ComputerName
	)
	Node $ComputerName
	{
		Settings
		{
			ConfigurationMode  = 'ApplyAndMonitor'
			ActionAfterReboot  = 'StopConfiguration'
			RebootNodeIfNeeded = $False
			RefreshMode        = 'Disabled'
		}
	}
}
LCMv5 -ComputerName localhost
Set-DscLocalConfigurationManager .\LCMv5

# View the LCM configuration
Get-DscLocalConfigurationManager
Get-DscLocalConfigurationManager | Format-List -Property ConfigurationMode, RefreshMode, ActionAfterReboot, RebootNodeIfNeeded

# Configure the LCM for autocorrect all the time
[DscLocalConfigurationManager()]
Configuration LCMv5
{
	Param (
		$ComputerName
	)
	Node $ComputerName
	{
		Settings
		{
			ConfigurationMode  = 'ApplyAndAutocorrect'
			ActionAfterReboot  = 'ContinueConfiguration'
			RebootNodeIfNeeded = $True
			RefreshMode        = 'Push'
		}
	}
}
LCMv5 -ComputerName localhost
Set-DscLocalConfigurationManager .\LCMv5

# View the LCM configuration
Get-DscLocalConfigurationManager | Format-List -Property ConfigurationMode, RefreshMode, ActionAfterReboot, RebootNodeIfNeeded
Install-Module xPendingReboot -Verbose

# View the xPendingReboot logic and Set function
Get-ChildItem -Path 'C:\Program Files\WindowsPowerShell\Modules\xPendingReboot\' -Recurse -Filter MSFT_xPendingReboot.psm1 | ForEach-Object -Process {
	powershell_ise.exe $($_.FullName) 
}


Configuration TestPendingReboot{
    Param(
        [string]$ComputerName='localhost'
    )

    Import-DSCResource -ModuleName xPendingReboot
    Import-DSCResource -ModuleName PSDesiredStateConfiguration
    Node $ComputerName
    {
        File Testfile
        {
            DestinationPath = "c:\DropZone\Test.txt"
            Ensure = "Present"
            Contents = "Test file"
            Type = "File"
        }
        xPendingReboot ManualReboot
        {
            Name = "Manual Reboot"
            DependsOn = "[File]Testfile"
        }

        LocalConfigurationManager
        {
            ActionAfterReboot  = 'StopConfiguration'
            RebootNodeIfNeeded = $True
        }
    }
}


TestPendingReboot
Set-DscLocalConfigurationManager .\TestPendingReboot
Get-DscLocalConfigurationManager
Start-DscConfiguration -Path .\TestPendingReboot -Wait -Verbose -Force

New-Item -Path "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\WindowsUpdate\Auto Update" -Name RebootRequired -Force
Start-DscConfiguration -Path .\TestPendingReboot -Wait -Verbose -Force

# View reboot status
Get-DscConfigurationStatus
Get-DscConfigurationStatus -All


# View reboot status remotely
$cim = New-CimSession -ComputerName ms1.contoso.com, ms2.contoso.com
Get-DscLocalConfigurationManager -CimSession $cim | Format-Table -Property PSComputerName, LCMState, ConfigurationMode, RefreshMode, ActionAfterReboot, RebootNodeIfNeeded -AutoSize
Get-DscConfigurationStatus -CimSession $cim
Get-DscConfigurationStatus -CimSession $cim -All
Remove-CimSession $cim

#Requires -RunAsAdministrator 
#Requires -Version 4
Clear-Host 
$CurrentDir = Split-Path -Path $MyInvocation.MyCommand.Path -Parent
#$CurrentDir="C:PShellDemos\Module06"

#To use TLS 1.2
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12

Set-Location -Path $CurrentDir

Install-Module xStorage -Verbose
#Update-Module xStorage -Verbose

# Notice similarities and differences of folder structure
Set-Location -Path 'C:\Program Files\WindowsPowerShell\Modules\'
tree /f /a

# A simple resource example
Set-Location -Path 'C:\Program Files\WindowsPowerShell\Modules\xStorage'
tree /f /a

# Collapse the function regions for an overview
# Walk through each function
Get-ChildItem -Recurse -Filter MSFT_xDisk.psm1 | ForEach-Object -Process {
	powershell_ise.exe $($_.FullName) 
}


# The resource MOF
Get-ChildItem -Recurse -Filter MSFT_xDisk.schema.mof | ForEach-Object -Process {
	powershell_ise.exe $($_.FullName) 
}


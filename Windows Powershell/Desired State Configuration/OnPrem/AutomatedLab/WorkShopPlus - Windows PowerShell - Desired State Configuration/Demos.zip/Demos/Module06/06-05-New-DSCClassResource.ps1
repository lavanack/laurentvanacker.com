#Requires -RunAsAdministrator 
#Requires -Version 4
Clear-Host 
$CurrentDir = Split-Path -Path $MyInvocation.MyCommand.Path -Parent
#$CurrentDir="C:PShellDemos\Module06"

Set-Location -Path $CurrentDir

#region Create resource module

mkdir -Path contosoClassResources -Force
Set-Location -Path .\contosoClassResources

New-Item -ItemType File -Name contosoClassResources.psm1 -Force

New-ModuleManifest -PowerShellVersion '5.0' -DscResourcesToExport FileResource,FileTextResource -RootModule contosoClassResources.psm1 -Path contosoClassResources.psd1 -ModuleVersion '1.0' | Out-Null

# Notice no extra folders or schema.mof
dir

# Note the DscResourcesToExport key
powershell_ise contosoClassResources.psd1

#endregion

Copy-Item $CurrentDir\06-05-contosoClassResources.psm1 contosoClassResources.psm1 -Force

# Review and edit the .psm1 file
# A single file with two resources
powershell_ise.exe contosoClassResources.psm1


#region Move the module into the PSModulePath for discovery

Copy-Item $CurrentDir\contosoClassResources $Env:ProgramFiles\WindowsPowerShell\Modules -Recurse -Force
dir $Env:ProgramFiles\WindowsPowerShell\Modules\contosoClassResources

#endregion


#region Test the resource

configuration ContosoResourceTest
{
    Import-DscResource -ModuleName contosoClassResources

    node localhost
    {
        FileTextResource TestTextFile
        {
           Ensure = 'Present'
           Path   = 'C:\DropZone\Sample.txt'
           Value  = "This came from the class resource."
        }
    }
}

ContosoResourceTest
Start-DscConfiguration -Path .\ContosoResourceTest -Wait -Verbose -Force

# View and change the file
notepad C:\DropZone\Sample.txt
Start-DscConfiguration -Path .\ContosoResourceTest -Wait -Verbose


# Set to absent
configuration ContosoResourceTest
{
    Import-DscResource -ModuleName contosoClassResources

    node localhost
    {
        FileTextResource TestTextFile
        {
           Ensure = 'Absent'
           Path   = 'C:\DropZone\Sample.txt'
           Value  = "This came from the class resource."
        }
    }
}

ContosoResourceTest
Start-DscConfiguration -Path .\ContosoResourceTest -Wait -Verbose
dir C:\DropZone\Sample.txt
#endregion




#region Reset DO NOT RUN
#Set-Location $CurrentDir
#Remove-Item $Env:ProgramFiles\WindowsPowerShell\Modules\contosoClassResources -Recurse -Force
#Remove-Item $CurrentDir\contosoClassRes* -Recurse -Force

#endregion


<#
NOTE: This class resource example code has a logic error.
When set to Absent, it will only remove the file if its
content matches. Fix this later.
#>

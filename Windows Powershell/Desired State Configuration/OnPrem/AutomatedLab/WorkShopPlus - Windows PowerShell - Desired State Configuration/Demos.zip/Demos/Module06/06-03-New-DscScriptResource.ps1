#Requires -RunAsAdministrator 
#Requires -Version 4
Clear-Host 
$CurrentDir = Split-Path -Path $MyInvocation.MyCommand.Path -Parent
#$CurrentDir="C:PShellDemos\Module06"

#To use TLS 1.2
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12

Set-Location -Path $CurrentDir

# Update the version of the designer module
Get-Module xDSCResourceDesigner -ListAvailable | Select-Object -ExpandProperty Version

Remove-Item 'C:\Program Files\WindowsPowerShell\Modules\xDSCResourceDesigner' -Recurse -Force
Install-Module xDSCResourceDesigner -Force -Verbose

Get-Module xDSCResourceDesigner -ListAvailable | Select-Object -ExpandProperty Version

Get-Command -Module xDSCResourceDesigner
Get-ChildItem -Path 'C:\Program Files\WindowsPowerShell\Modules\xDSCResourceDesigner\' -Recurse -Filter xDSCResourceDesigner.psm1 | ForEach-Object { powershell_ise.exe $($_.FullName) }


#region Create resource


# New resource with properties
New-xDscResource -Name CONTOSO_contosoTextFile -FriendlyName contosoTextFile -ModuleName contosoResources `
 -Path . -Force -Property @(
    New-xDscResourceProperty -Name Path -Type String -Attribute Key
    New-xDscResourceProperty -Name Value -Type String -Attribute Write
    New-xDscResourceProperty -Name Ensure -Type String -Attribute Required -ValidateSet 'Present','Absent'
)

tree .\contosoResources /f /a

# Note the DscResourcesToExport key
powershell_ise.exe .\contosoResources\contosoResources.psd1

powershell_ise.exe .\contosoResources\DSCResources\CONTOSO_contosoTextFile\CONTOSO_contosoTextFile.schema.mof
powershell_ise.exe .\contosoResources\DSCResources\CONTOSO_contosoTextFile\CONTOSO_contosoTextFile.psm1

#endregion

Copy-Item .\06-03-CONTOSO_contosoTextFile.psm1 .\contosoResources\DSCResources\CONTOSO_contosoTextFile\CONTOSO_contosoTextFile.psm1
powershell_ise.exe .\contosoResources\DSCResources\CONTOSO_contosoTextFile\CONTOSO_contosoTextFile.psm1


#region Move the module into the PSModulePath for discovery

Copy-Item $CurrentDir\contosoResources $Env:ProgramFiles\WindowsPowerShell\Modules -Recurse -Force
tree $Env:ProgramFiles\WindowsPowerShell\Modules\contosoResources /f /a

#endregion

Get-DscResource contosoTextFile -Syntax


#region Test the resource

configuration ContosoResourceTest
{
    Import-DscResource -ModuleName contosoResources

    node localhost
    {
        contosoTextFile TestTextFile
        {
           Ensure = 'Present'
           Path   = 'C:\DropZone\Sample.txt'
           Value  = "Simple text test."
        }
    }
}

ContosoResourceTest
Start-DscConfiguration -Path .\ContosoResourceTest -Wait -Verbose -Force

# View and change the file
notepad C:\DropZone\Sample.txt
Start-DscConfiguration -Path .\ContosoResourceTest -Wait -Verbose


Clear-Host
Get-DscConfiguration


# Now set to Absent
configuration ContosoResourceTest
{
    Import-DscResource -ModuleName contosoResources

    node localhost
    {
        contosoTextFile TestTextFile
        {
           Ensure = 'Absent'
           Path = 'C:\DropZone\Sample.txt'
        }
    }
}

ContosoResourceTest
Start-DscConfiguration -Path .\ContosoResourceTest -Wait -Verbose

#endregion




#region Reset  DO NOT RUN

#Remove-Item $Env:ProgramFiles\WindowsPowerShell\Modules\contosoResources -Recurse -Force

#endregion

#Requires -RunAsAdministrator 
#Requires -Version 4
Clear-Host 
$CurrentDir = Split-Path -Path $MyInvocation.MyCommand.Path -Parent
#$CurrentDir="C:PShellDemos\Module06"

Set-Location -Path $CurrentDir


# Unit testing
# View and run the test cases in the comments at the bottom
powershell_ise.exe $CurrentDir\06-05-contosoClassResources.psm1



# LCM debug mode in WMF 5.0 and WMF 4.0 KB3000850
# Requires resources from previous examples
Configuration LCMv4
{
	Node localhost
	{
		LocalConfigurationManager
		{
			RefreshMode = 'Disabled'
		}
	}
}
LCMv4
Set-DscLocalConfigurationManager -Path .\LCMv4
Get-DscLocalConfigurationManager | Format-Table -Property DebugMode, RefreshMode -AutoSize


# Class-based resources 
Invoke-DscResource -Module contosoResources -Name contosoTextFile -Method Set -Property @{Ensure = 'Present';Path = 'C:\DropZone\test.txt';Value = 'Hello, world !!!!!!!!!!!!!'}

# Set Present
$Splat = @{
	Verbose  = $true
	Module   = 'contosoResources'
	Name     = 'contosoTextFile'
	Method   = 'Set'
	Property = @{
		Ensure = 'Present'
		Path = 'C:\DropZone\test.txt'
		Value = 'Hello, world.'
	}
}
Invoke-DscResource @Splat

# Test
$Splat = @{
	Verbose  = $true
	Module   = 'contosoResources'
	Name     = 'contosoTextFile'
	Method   = 'Test'
	Property = @{
		Ensure = 'Present'
		Path = 'C:\DropZone\test.txt'
		Value = 'Hello, world.'
	}
}
Invoke-DscResource @Splat

# Set Absent
$Splat = @{
	Verbose  = $true
	Module   = 'contosoResources'
	Name     = 'contosoTextFile'
	Method   = 'Set'
	Property = @{
		Ensure = 'Absent'
		Path = 'C:\DropZone\test.txt'
		Value = 'Hello, world.'
	}
}
Invoke-DscResource @Splat




# Test file resource
$Splat = @{
	Verbose  = $true
	Module   = 'PSDesiredStateConfiguration'
	Name     = 'File'
	Method   = 'Test'
	Property = @{
		Ensure = 'Absent'
		DestinationPath = 'C:\DropZone\test.txt'
		Type = 'File'
		Contents = 'Hello, world.'
	}
}
Invoke-DscResource @Splat



# Reset LCM
[DscLocalConfigurationManager()]
Configuration LCMv5
{
	Node localhost
	{
		Settings
		{
			DebugMode   = 'None'
			RefreshMode = 'Push'
		}
	}
}
LCMv5
Set-DscLocalConfigurationManager -Path .\LCMv5
Get-DscLocalConfigurationManager | Format-Table -Property DebugMode, RefreshMode -AutoSize

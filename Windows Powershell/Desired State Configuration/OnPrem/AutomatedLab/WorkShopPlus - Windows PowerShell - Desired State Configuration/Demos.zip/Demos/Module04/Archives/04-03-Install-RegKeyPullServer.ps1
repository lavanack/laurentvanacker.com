﻿#Requires -RunAsAdministrator 
#Requires -Version 4
Clear-Host 
$CurrentDir = Split-Path -Path $MyInvocation.MyCommand.Path -Parent
#$CurrentDir="C:PShellDemos\Module04"

#To use TLS 1.2
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12

Set-Location -Path $CurrentDir

Install-Module xPSDesiredStateConfiguration -Force -Verbose
$CertificateThumbprint = (Get-ChildItem -Path Cert:\LocalMachine\My -SSLServerAuthentication | Select -Last 1).Thumbprint

configuration Sample_xDscWebService 
{ 
	param  
	( 
		[string[]]$NodeName = 'localhost', 

		#[ValidateNotNullOrEmpty()] 
		#[string] $certificateThumbPrint,

		[Parameter(Mandatory)]
		[ValidateNotNullOrEmpty()]
		[string] $RegistrationKey 
	) 


	Import-DSCResource -ModuleName xPSDesiredStateConfiguration
	Import-DSCResource -ModuleName PSDesiredStateConfiguration

	Node $NodeName 
	{ 
		WindowsFeature DSCServiceFeature 
		{ 
			Ensure = 'Present' 
			Name   = 'DSC-Service'             
		} 

		xDscWebService PSDSCPullServer 
		{ 
			Ensure                  = 'Present' 
			EndpointName            = 'PSDSCPullServer' 
			Port                    = 8080 
			PhysicalPath            = "$env:SystemDrive\inetpub\PSDSCPullServer" 
			#CertificateThumbPrint   =  $CertificateThumbPrint          
			CertificateThumbPrint   =  'AllowUnencryptedTraffic'
			ModulePath              = "$env:PROGRAMFILES\WindowsPowerShell\DscService\Modules" 
			ConfigurationPath       = "$env:PROGRAMFILES\WindowsPowerShell\DscService\Configuration"             
			State                   = 'Started' 
			DependsOn               = '[WindowsFeature]DSCServiceFeature'
			UseSecurityBestPractices = $false                         
		} 

		File RegistrationKeyFile
		{
			Ensure          = 'Present'
			Type            = 'File'
			DestinationPath = "$env:PROGRAMFILES\WindowsPowerShell\DscService\RegistrationKeys.txt"
			Contents        = $RegistrationKey
		}
	}
}

$RegKey = (New-Guid).Guid
Sample_xDscWebService -RegistrationKey $RegKey

Start-DscConfiguration -Path .\Sample_xDscWebService -Wait -Verbose -Force

#Start-Process -FilePath "https://$($Env:ComputerName).contoso.com:8080/PSDSCPullServer.svc"
Start-Process -FilePath "http://$($Env:ComputerName).contoso.com:8080/PSDSCPullServer.svc"

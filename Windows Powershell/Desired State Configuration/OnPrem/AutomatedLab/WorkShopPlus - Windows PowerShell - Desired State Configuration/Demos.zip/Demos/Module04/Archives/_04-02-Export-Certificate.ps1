#Requires -RunAsAdministrator 
#Requires -Version 4
Clear-Host 
$CurrentDir = Split-Path -Path $MyInvocation.MyCommand.Path -Parent
#$CurrentDir="C:PShellDemos\Module01"

Set-Location -Path $CurrentDir

# Certificate provider drive
Set-Location -Path cert:

# Dynamic parameters of Get-ChildItem
Get-ChildItem -Recurse

# Local machine certs for DSC
Get-ChildItem -Path Cert:\LocalMachine\My

Get-ChildItem Cert:\LocalMachine\My -DocumentEncryptionCert

$Cert = Get-ChildItem Cert:\LocalMachine\My -DocumentEncryptionCert | Select-Object -Last 1
Protect-CmsMessage -To $Cert -Content 'Encrypted with my new cert from the new template!'
Get-Process | Protect-CmsMessage -To $Cert

Set-Location -Path cert:

$Cert = Get-ChildItem Cert:\LocalMachine\My -DocumentEncryptionCert | Select-Object -Last 1
$Cert

# Export the public key certificate
$Cert | Export-Certificate -FilePath "$env:temp\DscPublicKey.cer" -Force 

# Export the public key
mkdir -Path C:\publicKeys -ErrorAction SilentlyContinue
Export-Certificate -Cert $Cert -FilePath "c:\publicKeys\$env:COMPUTERNAME.cer" -Force

# Query the thumbprint
Get-PfxCertificate -FilePath "C:\publicKeys\$env:COMPUTERNAME.cer"

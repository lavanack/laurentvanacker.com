﻿#Requires -RunAsAdministrator 
#Requires -Version 4
Clear-Host 
$CurrentDir = Split-Path -Path $MyInvocation.MyCommand.Path -Parent
#$CurrentDir="C:PShellDemos\Module01"

Set-Location -Path $CurrentDir

$nodes = 'pull', 'ms1', 'ms2'

# Verify that each node has autoenrolled a certificate
Invoke-Command -ComputerName $nodes -ScriptBlock {
	Get-ChildItem Cert:\LocalMachine\My -DocumentEncryptionCert
}
#Invoke-Command -ScriptBlock {certutil -pulse;dir Cert:\LocalMachine\My -DocumentEncryptionCert} -ComputerName ms1,ms2

mkdir -Path C:\PublicKeys -ErrorAction SilentlyContinue
Remove-Item -Path C:\PublicKeys\*.* -Force -ErrorAction SilentlyContinue

ForEach ($node in $nodes) 
{
	$pss = New-PSSession $node
	$return = Invoke-Command -Session $pss -ScriptBlock {
		$null = mkdir -Path C:\PublicKeys -ErrorAction SilentlyContinue
		# Cert verify fails remotely due to Kerberos Double Hop
		#$cert = Get-ChildItem Cert:\LocalMachine\My -DocumentEncryptionCert | Where-Object {$_.Verify()} | Select-Object -Last 1
		$cert = Get-ChildItem Cert:\LocalMachine\My -DocumentEncryptionCert | Select-Object -Last 1
		$null = Export-Certificate -Cert $cert -FilePath "C:\PublicKeys\$Env:COMPUTERNAME.cer" -Force
		$cert.Thumbprint
	}
	Copy-Item -FromSession $pss -Path "C:\PublicKeys\$node.cer" -Destination C:\PublicKeys -Force

	[PSCustomObject]@{
		Node       = $node
		Path       = "C:\PublicKeys\$node.cer"
		Thumbprint = $return
	} | Export-Csv -Path C:\PublicKeys\index.csv -Append -NoTypeInformation

	Remove-PSSession $pss
}

Import-Csv -Path C:\PublicKeys\index.csv
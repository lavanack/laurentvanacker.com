#Requires -RunAsAdministrator 
#Requires -Version 4
Clear-Host 
$CurrentDir = Split-Path -Path $MyInvocation.MyCommand.Path -Parent
#$CurrentDir="C:PShellDemos\Module04"

Set-Location -Path $CurrentDir

# Credential handling in DSC
#region Resources with credential parameters

$DscResource = Get-DscResource

# All credential resources
$DscResource | ForEach-Object -Process {
	$_
	$_ |
	Select-Object -ExpandProperty Properties |
	Where-Object -Property PropertyType -EQ -Value '[PSCredential]' |
	Format-Table -AutoSize
}

# All mandatory credential resources
$DscResource | ForEach-Object -Process {
	$_
	$_ |
	Select-Object -ExpandProperty Properties |
	Where-Object -FilterScript {
		$_.PropertyType -eq '[PSCredential]' -and $_.IsMandatory -eq $true
	} |
	Format-Table -AutoSize
}

# Group resource
$DscResource |
Where-Object -Property name -EQ -Value 'Group' |
ForEach-Object -Process {
	$_
	$_ |
	Select-Object -ExpandProperty Properties |
	Format-Table -AutoSize
}

#endregion


#region Unencrypted example
Configuration PlainTextPassword
{
	Param(
		[Parameter(Mandatory = $true)]
		[PsCredential]$Credential
	)

	Import-DscResource -ModuleName PSDesiredStateConfiguration

	Node $AllNodes.NodeName
	{
		Group TestGroup
		{
			GroupName = 'Backup Operators'
			Members = 'contoso\ericlang'
			Ensure = 'Present'
			Credential = $Credential
		}
	}
} 

$ConfigData = @{
	AllNodes = @(
		@{
			NodeName                    = 'localhost'
			PSDscAllowPlainTextPassword = $true
			PSDscAllowDomainUser        = $true
		}
	)
}

PlainTextPassword -ConfigurationData $ConfigData `
-Credential (Get-Credential -Message 'Enter credentials for configuration' -UserName 'contoso\administrator') 

notepad.exe .\PlainTextPassword\localhost.mof

#endregion


#region Encrypted example
Configuration EncryptedPassword
{
	Param(
		[Parameter(Mandatory = $true)]
		[PsCredential]$Credential
	)

	Import-DscResource -ModuleName PSDesiredStateConfiguration

	Node $AllNodes.NodeName
	{
		Group TestGroup
		{
			GroupName = 'Backup Operators'
			Members = 'contoso\ericlang'
			Ensure = 'Present'
			Credential = $Credential
		}
        
		LocalConfigurationManager
		{
			CertificateId = $node.Thumbprint
		}
	}
} 

$ConfigData = @{
	AllNodes = @(
		@{
			NodeName                    = 'pull'
			PSDscAllowPlainTextPassword = $false
			PSDscAllowDomainUser        = $true
			CertificateFile             = "c:\publicKeys\pull.cer"
			Thumbprint                  = (Get-PfxCertificate -FilePath "C:\publicKeys\pull.cer").Thumbprint
		}
	)
}

EncryptedPassword -ConfigurationData $ConfigData `
-Credential (Get-Credential -Message 'Enter credentials for configuration' -UserName 'contoso\administrator') 

notepad.exe .\EncryptedPassword\pull.mof

#endregion

# Set up LCM to decrypt credentials
Set-DscLocalConfigurationManager -Path .\EncryptedPassword -Verbose 

# Note CertificateID
Get-DscLocalConfigurationManager

# Start configuration
Start-DscConfiguration -Path .\EncryptedPassword -Wait -Verbose -Force

# Confirm change
Get-LocalGroupMember 'Backup Operators' 

# Remove user
Remove-LocalGroupMember -Group 'Backup Operators' -Member 'contoso\ericlang'


#region Encrypted example
Configuration EncryptedPassword
{
	Param(
		[Parameter(Mandatory = $true)]
		[PsCredential]$Credential
	)

	Import-DscResource -ModuleName PSDesiredStateConfiguration

	Node $AllNodes.NodeName
	{
		Group TestGroup
		{
			GroupName = 'Backup Operators'
			Members = 'contoso\ericlang'
			Ensure = 'Present'
			Credential = $Credential
		}
        
		LocalConfigurationManager
		{
			CertificateId = $node.Thumbprint
		}
	}
} 

$ConfigData = @{
	AllNodes = @(
		@{
			NodeName                    = 'ms1'
			PSDscAllowPlainTextPassword = $false
			PSDscAllowDomainUser        = $true
			CertificateFile             = "c:\publicKeys\ms1.cer"
			Thumbprint                  = (Get-PfxCertificate -FilePath "C:\publicKeys\ms1.cer").Thumbprint
		}
	)
}


# Generating configuration Data for MS1
EncryptedPassword -ConfigurationData $ConfigData `
-Credential (Get-Credential -Message 'Enter credentials for configuration' -UserName 'contoso\administrator') 

notepad.exe .\EncryptedPassword\ms1.mof

# Encrypting the MOF files by using Protect-CmsMessage
Copy-Item .\EncryptedPassword\ms1.mof .\EncryptedPassword\ms1.backup.mof_
Protect-CmsMessage -Content (Get-Content .\EncryptedPassword\ms1.backup.mof_) -To C:\publicKeys\ms1.cer -OutFile .\EncryptedPassword\ms1.encrypted.mof_ -Verbose
notepad.exe .\EncryptedPassword\ms1.encrypted.mof_
$MS1MOFContent= Get-Content .\EncryptedPassword\ms1.encrypted.mof_

# Decrypting the MOF files by using unprotect-CmsMessage on ms1 because the private key is required
Invoke-Command -ComputerName ms1 -ScriptBlock { $using:MS1MOFContent | Unprotect-CmsMessage}


# Set up LCM to decrypt credentials
Set-DscLocalConfigurationManager -Path .\EncryptedPassword -ComputerName ms1 -Verbose 

# Start configuration
Start-DscConfiguration -Path .\EncryptedPassword -ComputerName ms1 -Wait -Verbose -Force

﻿#Requires -RunAsAdministrator 
#Requires -Version 4
Clear-Host 
$CurrentDir = Split-Path -Path $MyInvocation.MyCommand.Path -Parent
#$CurrentDir="C:PShellDemos\Module09"

Set-Location -Path $CurrentDir


# Reset all LCMs from previous demos
Invoke-Command -ComputerName ms1, ms2, pull -ScriptBlock {
	Remove-Item -Path C:\Windows\System32\Configuration\metaconfig.mof -Force -ErrorAction SilentlyContinue
}

[DSCLocalConfigurationManager()]
configuration PartialConfigDemo
{
	Param(
		[String]$ComputerName,
		[String]$GUID
	)
	Node $ComputerName
    {
        Settings
        {
            RefreshMode             = 'Pull'
            ConfigurationID         = $GUID
            RefreshFrequencyMins    = 30 
            RebootNodeIfNeeded      = $true
        }
        ConfigurationRepositoryWeb PullHTTP
        {
            ServerURL               = 'http://pull.contoso.com:8080/psdscpullserver.svc'

        }
        PartialConfiguration IISSetup
        {
            Description             = 'Setup for IIS'
            ConfigurationSource     = '[ConfigurationRepositoryWeb]PullHTTP'
            RefreshMode             = 'Pull'
        }
        PartialConfiguration IISConfig
        {
            Description             = 'Configuration for IIS (Post setup)'
            DependsOn               = '[PartialConfiguration]IISSetup'
            RefreshMode             = 'Push'
        }
    }
}

$GUID = (New-Guid).Guid
$Node = 'ms1.contoso.com'

PartialConfigDemo -Computername $Node -GUID $GUID
psedit .\PartialConfigDemo\ms1.contoso.com.meta.mof

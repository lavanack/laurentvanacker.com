#Requires -RunAsAdministrator 
#Requires -Version 4
Clear-Host 
$CurrentDir = Split-Path -Path $MyInvocation.MyCommand.Path -Parent
#$CurrentDir="C:PShellDemos\Module09"

Set-Location -Path $CurrentDir

$Node = 'ms1.contoso.com'
$cim = New-CimSession -ComputerName $Node


#region ##### Set LCM #####

Set-DscLocalConfigurationManager -Path .\PartialConfigDemo -CimSession $cim -Verbose

# Explore partials
Get-DscLocalConfigurationManager -CimSession $cim
(Get-DscLocalConfigurationManager -CimSession $cim).ConfigurationDownloadManagers
(Get-DscLocalConfigurationManager -CimSession $cim).PartialConfigurations

#endregion



#region ##### IISConfig PULL HTTP #####


$Source = ".\IISConfig\$Node.mof"
$Destination = "C:\Program Files\WindowsPowerShell\DSCService\Configuration\IISConfig.$GUID.mof"

Copy-Item -Path $Source -Destination $Destination
New-DscChecksum $Destination -Force -Verbose

Get-ChildItem -Path 'C:\Program Files\WindowsPowerShell\DSCService\Configuration\'

#endregion



#region ##### MAKE IT SO #####

# This will error due to IISSetup PUSH dependency not present
Update-DscConfiguration -CimSession $cim -Wait -Verbose

#endregion



#region ##### Publish partial configurations #####
Publish-DscConfiguration -CimSession $cim -Path .\IISConfig -Verbose -Force
Publish-DscConfiguration -CimSession $cim -Path .\IISSetup -Verbose
#Copy-Item -Path .\IISSetup\ms1.contoso.com.mof -Destination \\ms1\c$\Windows\System32\Configuration\pending.mof

# View the push partial configuration
Invoke-Command -ComputerName $Node -ScriptBlock {
	Get-ChildItem -Path C:\Windows\System32\Configuration
}

Invoke-Command -ComputerName $Node -ScriptBlock {
	Get-ChildItem -Path C:\Windows\System32\Configuration\PartialConfigurations
}

#endregion



#region ##### MAKE IT SO #####

#Update-DscConfiguration -CimSession $cim -Wait -Verbose
Start-DscConfiguration -CimSession $cim -Wait -Verbose -UseExisting -Force

Get-DscConfiguration -CimSession $cim
Get-DscConfigurationStatus -CimSession $cim -All

#endregion

Remove-CimSession $cim

# RESET
<#
$sb = {
	Remove-Item -Path C:\Windows\System32\Configuration\Partial* -Force -Confirm:$false
	Remove-Item -Path C:\Windows\System32\Configuration\PartialConfigurations\* -Force -Confirm:$false
	Uninstall-WindowsFeature -Name Web-Server
	Restart-Computer -Force
}
Invoke-Command -ComputerName $Node -ScriptBlock $sb
#>

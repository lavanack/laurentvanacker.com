#Requires -RunAsAdministrator 
#Requires -Version 4
Clear-Host 
$CurrentDir = Split-Path -Path $MyInvocation.MyCommand.Path -Parent
#$CurrentDir="C:PShellDemos\Module09"

Set-Location -Path $CurrentDir




#region ##### IISSetup PULL HTTP #####

# Sample configuration
Configuration IISSetup {
	param ([string[]]$ComputerName = 'localhost')

	Import-DscResource -ModuleName PSDesiredStateConfiguration

	Node $ComputerName 
    {
		WindowsFeature IIS {
			Ensure = 'Present'
			Name   = 'Web-Server'
		}
	}
}

IISSetup -ComputerName $Node

#endregion


#region ##### IISConfig PUSH #####

Configuration IISConfig {
	param ([string[]]$ComputerName = 'localhost')

	Import-DscResource -ModuleName PSDesiredStateConfiguration

	Node $ComputerName 
    {
		File IISDefaultPage
        {
            DestinationPath = "C:\inetpub\wwwroot\iisstart.htm"
            Contents = "<HTML><HEAD><TITLE>Installed via DSC</TITLE></HEAD><BODY><H1>If you are seeing this page. It means the website is under maintenance and DSC Rocks !!!</H1></BODY></HTML>"
            Ensure = "Present"
            Type = "File" 
            Force = $True
        }
	}
}

IISConfig -ComputerName $Node

#endregion


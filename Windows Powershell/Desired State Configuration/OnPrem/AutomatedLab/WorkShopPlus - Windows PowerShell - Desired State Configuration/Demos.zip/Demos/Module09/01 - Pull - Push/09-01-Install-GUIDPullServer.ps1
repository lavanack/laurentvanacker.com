#Requires -RunAsAdministrator 
#Requires -Version 4
Clear-Host 
$CurrentDir = Split-Path -Path $MyInvocation.MyCommand.Path -Parent
#$CurrentDir="C:PShellDemos\Module09"

#To use TLS 1.2
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12

Set-Location -Path $CurrentDir

Install-Module -Name xPSDesiredStateConfiguration -Force -Verbose
$CertificateThumbprint = (Get-ChildItem -Path Cert:\LocalMachine\My -SSLServerAuthentication | Select-Object -Last 1).Thumbprint

# Configuration for a simple PULL server, unencrypted HTTP
configuration CreatePullServer
{
	param
	(
		[string[]]
		$ComputerName = 'localhost'
	)

	Import-DSCResource -ModuleName PSDesiredStateConfiguration
	# Update the module version appropriately
	Import-DSCResource -ModuleName xPSDesiredStateConfiguration

	Node $ComputerName
	{
		WindowsFeature DSCServiceFeature
		{
			Ensure = 'Present'
			Name   = 'DSC-Service'
		}
		xDscWebService PSDSCPullServer
		{
			Ensure                  = 'Present'
			EndpointName            = 'PSDSCPullServer'
			Port                    = 8080
			PhysicalPath            = "$env:SystemDrive\inetpub\wwwroot\PSDSCPullServer"
			CertificateThumbPrint   = 'AllowUnencryptedTraffic'
			ModulePath              = "$env:PROGRAMFILES\WindowsPowerShell\DscService\Modules"
			ConfigurationPath       = "$env:PROGRAMFILES\WindowsPowerShell\DscService\Configuration"
			State                   = 'Started'
			DependsOn               = '[WindowsFeature]DSCServiceFeature'
			UseSecurityBestPractices = $false
		}
	}
}

# Build the MOF
CreatePullServer -ComputerName $Env:ComputerName

# Apply the configuration.
Start-DscConfiguration .\CreatePullServer -Wait -Verbose

# View the web service
Start-Process -FilePath "http://$($Env:ComputerName).contoso.com:8080/PSDSCPullServer.svc"

# Notice DSC-Service under Windows PowerShell
Get-WindowsFeature | Where-Object -Property DisplayName -Like -Value '*PowerShell*'

# Optional IIS console
Install-WindowsFeature Web-Mgmt-Console

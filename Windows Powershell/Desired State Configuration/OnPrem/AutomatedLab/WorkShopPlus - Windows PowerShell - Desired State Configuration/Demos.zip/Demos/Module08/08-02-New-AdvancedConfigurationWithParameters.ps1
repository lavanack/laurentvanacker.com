#Requires -RunAsAdministrator 
#Requires -Version 4
Clear-Host 
$CurrentDir = Split-Path -Path $MyInvocation.MyCommand.Path -Parent
#$CurrentDir="C:PShellDemos\Module08"

Configuration myWebServer {
	Param ( 
		[String[]]$ComputerName = $env:COMPUTERNAME, 
        
		[Parameter(Mandatory)]
		[String[]]$WindowsFeature
	)

	Import-DSCResource -ModuleName PSDesiredStateConfiguration

	Node $ComputerName 
	{
		foreach ($Feature in $WindowsFeature)
		{
			Write-Verbose -Message $Feature
			WindowsFeature $Feature 
			{
				Name   = $Feature
				Ensure = 'Present'
			}
		}
	}
}

$WebFeatures = 'Web-Server', 'Web-Mgmt-Service'
myWebServer -ComputerName ms1 -WindowsFeature $WebFeatures
psEdit -filenames .\myWebServer\ms1.mof

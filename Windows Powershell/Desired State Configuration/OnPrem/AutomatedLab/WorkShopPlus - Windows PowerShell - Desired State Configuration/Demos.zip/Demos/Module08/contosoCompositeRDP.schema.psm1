Configuration contosoCompositeRDP {
    Param
    (       
        [pscredential]$Credential,       
        [string]$Members
    )
    Import-DscResource -Module PSDesiredStateConfiguration,xRemoteDesktopAdmin
    Import-DscResource -ModuleName @{ModuleName="xNetworking";RequiredVersion="2.3.0.0"}


    xRemoteDesktopAdmin RemoteDesktopSettings
    {
        Ensure             = 'Present'
        UserAuthentication = 'Secure'
    }

    xFirewall AllowRDP
    {
        Name         = 'DSC - Remote Desktop Admin Connections'
        DisplayGroup = "Remote Desktop"
        Ensure       = 'Present'
        State        = 'Enabled'
        Access       = 'Allow'
        Profile      = 'Domain'
    }

    Group RDPGroup
    {
        Ensure           = 'Present'
        GroupName        = 'Remote Desktop Users'
        MembersToInclude = $Members
        Credential       = $Credential
    }
}
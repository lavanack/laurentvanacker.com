#Requires -RunAsAdministrator 
#Requires -Version 4
Clear-Host 
$CurrentDir = Split-Path -Path $MyInvocation.MyCommand.Path -Parent
#$CurrentDir="C:PShellDemos\Module08"

Set-Location -Path $CurrentDir

Configuration myWebServer {
	Param ( 
		[String[]]$ComputerName = $env:COMPUTERNAME
	)

	Import-DSCResource -ModuleName PSDesiredStateConfiguration

	Node $ComputerName 
	{
		WindowsFeature 'Web-Mgmt-Service' 
		{
			Name   = 'Web-Mgmt-Service'
			Ensure = 'Present'
		}
           
		WindowsFeature 'Web-Server'
		{
			Name   = 'Web-Server'
			Ensure = 'Present'
		}
	}
}

myWebServer -ComputerName ms1 -Verbose
psEdit -filenames .\myWebServer\ms1.mof

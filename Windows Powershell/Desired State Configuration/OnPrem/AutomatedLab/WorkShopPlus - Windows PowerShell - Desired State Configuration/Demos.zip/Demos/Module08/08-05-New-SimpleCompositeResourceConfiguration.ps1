#Requires -RunAsAdministrator 
#Requires -Version 5
Clear-Host 
$CurrentDir = Split-Path -Path $MyInvocation.MyCommand.Path -Parent
$CurrentDir = "C:\PShell\Demos\Module08"

#To use TLS 1.2
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12

Set-Location -Path $CurrentDir

Install-Module xPSDesiredStateConfiguration, xRemoteDesktopAdmin -verbose
Install-Module xNetworking -RequiredVersion '2.3.0.0' -Force -verbose

#From https://gallery.technet.microsoft.com/Helper-Function-to-Create-bf248c68
. "$CurrentDir\New-DSCCompositeResource.ps1"
New-DSCCompositeResource -ModuleName contosoCompositeResources -ResourceName contosoCompositeRDP
Copy-Item -Path C:\PShell\Demos\Module08\contosoCompositeRDP.schema.psm1 $env:ProgramFiles\WindowsPowerShell\Modules\contosoCompositeResources\DSCResources\contosoCompositeRDP -Force

Configuration SetRDPConfiguration {
param (
       [pscredential]$ReadADCred 
    )
   
   Import-DSCResource -ModuleName contosoCompositeResources

    Node $AllNodes.NodeName 
    {
       contosoCompositeRDP EnableRDP
       {
          Members    = "$env:USERDOMAIN\ericlang"
          Credential = $ReadADCred
       } 
    }
}

$Node = "ms1"
$CertFile = "\\pull\c$\publicKeys\$($Node).cer"
$Cert = Get-PfxCertificate -FilePath $CertFile

$ConfigData = @{
    AllNodes = @(
        @{
            NodeName        = $Node
            CertificateFile = $CertFile 
            Thumbprint      = $Cert.Thumbprint
         }
    )
}

$Cred = (Get-credential $env:USERDOMAIN\ericlang)
SetRDPConfiguration -ConfigurationData $ConfigData -ReadADCred $Cred -Verbose
psedit .\SetRDPConfiguration\ms1.mof


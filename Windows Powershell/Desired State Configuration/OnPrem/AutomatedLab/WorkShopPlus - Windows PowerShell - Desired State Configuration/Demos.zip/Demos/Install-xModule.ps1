#To use TLS 1.2
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12

#Install-PackageProvider -Name NuGet -MinimumVersion 2.8.5.201 -Force
#Install-Module -Name xDSCResourceDesigner, xDscDiagnostics, xNetworking, xPSDesiredStateConfiguration, xPendingReboot, xRemoteDesktopAdmin, xStorage -Force -Verbose
#Install-Module -Name xNetworking -MaximumVersion '2.4.0.0' -Force -Verbose
#Install-Module -Name xNetworking -RequiredVersion '2.3.0.0' -Force -verbose

#Forcing the use of TLS 1.2 via the profile for all users on all hosts
if ($profile.AllUsersAllHosts)
{
    $null=New-Item -Path $(Split-Path $profile.AllUsersAllHosts -Parent) -ItemType Directory -Force
    "Write-Host 'Adding SecurityProtocolType to TLS 1.2'`r`n[Net.ServicePointManager]::SecurityProtocol += [Net.SecurityProtocolType]::Tls12" | Out-File -FilePath $Profile.AllUsersAllHosts -Force #-Append
}
else
{
    $AllUsersAllHosts = Join-Path -Path $PSHOME -ChildPath 'profile.ps1'
    "Write-Host 'Adding SecurityProtocolType to TLS 1.2'`r`n[Net.ServicePointManager]::SecurityProtocol += [Net.SecurityProtocolType]::Tls12" | Out-File -FilePath $AllUsersAllHosts -Force #-Append
}
Start-Job -ScriptBlock {Update-Help -Force -Verbose -ErrorAction Ignore}
﻿$Nodes = "pull","ms1","ms2"
Invoke-Command -ComputerName $Nodes -ScriptBlock {
    Get-ChildItem  $env:Windir\System32\Configuration\ -Filter *.mof -Recurse
    <# Removing configuration for all stages
    foreach ($Stage in  'Current','Pending','Previous')
    {
        Remove-DscConfigurationDocument -Stage $Stage
    }
    #>
    #Removing all configs, logs and history
    Get-ChildItem  $env:Windir\System32\Configuration\ -Filter *.mof -Recurse | Remove-Item -Force -Verbose

    #Removing all configs including the Meta (LCM) config : will put the LCM back in the default state:
    #Get-ChildItem  $env:Windir\System32\Configuration\ -Filter *.mof | Remove-Item -Force -Verbose

    Get-DSCLocalconfigurationManager -Verbose -ErrorAction Ignore
}


#Requires -RunAsAdministrator 
#Requires -Version 4
Clear-Host 
$CurrentDir = Split-Path -Path $MyInvocation.MyCommand.Path -Parent
#$CurrentDir="C:PShellDemos\Module01"

Set-Location -Path $CurrentDir

# Module for DSC Management
Get-Command -Module PSDesiredStateConfiguration

# Engine status
Get-DscLocalConfigurationManager

# No configuration applied
Get-DscConfiguration


Configuration MyFirstConfig
{
	Import-DscResource -ModuleName PSDesiredStateConfiguration

	Node localhost
	{
		Registry AssetTag {
			Key = 'HKLM:\Software\Contoso'
			ValueName = 'AssetTag'
			ValueData = '420042'
			ValueType = 'DWORD'
			Ensure = 'Present'
		}

		Registry DecomStatus {
			Key = 'HKLM:\Software\Contoso'
			ValueName = 'Decom'
			ValueType = 'String'
			Ensure = 'Absent'
		}

		Service Bits {
			Name = 'Bits'
			State = 'Running'
		}
	}
}

# Generating the MOF file(s)
MyFirstConfig

# View the MOF
notepad.exe .\MyFirstConfig\localhost.mof

# Check state manually
Get-ItemProperty -Path HKLM:\Software\Contoso\
Get-Service -Name BITS

# Sets it the first time
Start-DscConfiguration -Wait -Verbose -Path .\MyFirstConfig

# Check state manually
Get-Item -Path HKLM:\Software\Contoso\
Get-Service -Name BITS

# View the config of the system
Get-DscConfiguration

# Check state with cmdlet
Test-DscConfiguration

# Change the state
Set-ItemProperty -Path HKLM:\Software\Contoso\ -Name AssetTag -Value 12
New-ItemProperty -Path HKLM:\Software\Contoso\ -Name Decom -Value True
Stop-Service -Name Bits

# Check state manually
Get-Item -Path HKLM:\Software\Contoso\
Get-Service -Name BITS

# Do I have the registry key? Is the value correct?
Test-DscConfiguration -Verbose
Test-DscConfiguration -Detailed

# Reset the state
Start-DscConfiguration -Wait -Verbose -Path .\MyFirstConfig

# Check state with cmdlet
Test-DscConfiguration


# Reset demo
# Reset
Remove-Item -Path C:\windows\System32\Configuration\*.mof -Force
Remove-Item -Path HKLM:\Software\Contoso\ -Recurse -Force
Stop-Service -Name BITS -Force
Remove-Item -Path .\MyFirstConfig -Recurse -Force -Confirm:$false

#Requires -RunAsAdministrator 
#Requires -Version 4
Clear-Host 
$CurrentDir = Split-Path -Path $MyInvocation.MyCommand.Path -Parent
#$CurrentDir="C:PShellDemos\Module02"

Set-Location -Path $CurrentDir

#Testing of the configuration is still correct 
Test-DscConfiguration
Test-DscConfiguration -Verbose
Test-DscConfiguration -Detailed

#Testing the current configuration
Get-DscConfiguration

#Getting the current configuration status
Get-DscConfigurationStatus
#Getting all the current configuration statuses
Get-DscConfigurationStatus -All


#Getting the current configuration status
Get-DscConfigurationStatus | Select-Object -Property * | Out-GridView
#Getting all the current configuration statuses
Get-DscConfigurationStatus -All | Select-Object -Property * | Out-GridView

# CIM sessions can take a number of robust parameters for connectivity and authentication
$cim = New-CimSession -ComputerName 'ms1', 'ms2'

#Testing the current configuration on the targeted nodes
Test-DscConfiguration -CimSession $cim
Test-DscConfiguration -CimSession $cim -Verbose
Test-DscConfiguration -CimSession $cim -Detailed

#Getting the current configuration on the targeted nodes
Get-DscConfiguration -CimSession $cim
Get-DscConfigurationStatus -CimSession $cim | Format-Table -AutoSize
Get-DscConfigurationStatus -All -CimSession $cim | Format-Table -AutoSize

#Removing the CIM session(s)
Remove-CimSession $cim

# Reset
Invoke-Command -ComputerName 'ms1', 'ms2' -ScriptBlock {
	Remove-Item -Path HKLM:\SOFTWARE\Contoso -Force -Recurse
	Remove-Item -Path C:\Windows\System32\Configuration\*.mof
}

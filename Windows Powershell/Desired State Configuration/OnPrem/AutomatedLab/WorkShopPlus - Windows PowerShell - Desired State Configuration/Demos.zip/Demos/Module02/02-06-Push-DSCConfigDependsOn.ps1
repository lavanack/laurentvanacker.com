#requires -Modules CimCmdlets, PSDesiredStateConfiguration
#Requires -RunAsAdministrator 
#Requires -Version 4.0
Clear-Host 
$CurrentDir = Split-Path -Path $MyInvocation.MyCommand.Path -Parent
#$CurrentDir="C:PShellDemos\Module02"

Set-Location -Path $CurrentDir

# Note the DependsOn properties
Configuration DependsOnExample {
	Import-DscResource -ModuleName PSDesiredStateConfiguration

	Node localhost {
		File DSCTempFolder {
			DestinationPath = 'C:\DSCTemp\'
			Ensure          = 'Present' 
			Type            = 'Directory'
		}

		Archive ExtractZIP {
			Ensure          = 'Present'
			Path            = 'C:\PShell\Demos\LogParser.zip'
			Destination     = 'C:\DSCTemp\logparser\'
			Force           = $true
			DependsOn       = '[File]DSCTempFolder'
		}

		Package InstallLogParser {
			Ensure          = 'Present'
			Name            = 'Log Parser 2.2'
			Path            = 'C:\DSCTemp\logparser\logparser.msi'
			ProductId       = '4AC23178-EEBC-4BAF-8CC0-AB15C8897AC9'
			DependsOn       = '[Archive]ExtractZIP'
		}
	}
}

# Generating the MOF file(s)
DependsOnExample
# Applying a new configuration
Start-DscConfiguration .\DependsOnExample -Wait -Verbose -Force

# Show app installed
Get-ChildItem -Path C:\DSCTemp
Get-CimInstance Win32_Product
# Show Start menu



# Uninstall
Configuration DependsOnExample {
	Import-DscResource -ModuleName PSDesiredStateConfiguration

	Node localhost {
		Package InstallLogParser {
			Ensure          = 'Absent'
			Name            = 'Log Parser 2.2'
			Path            = 'C:\DSCTemp\logparser\logparser.msi'
			ProductId       = '4AC23178-EEBC-4BAF-8CC0-AB15C8897AC9'
		}
	}
}
# Generating the MOF file(s)
DependsOnExample
# Applying a new configuration
Start-DscConfiguration .\DependsOnExample -Wait -Verbose

Get-CimInstance Win32_Product
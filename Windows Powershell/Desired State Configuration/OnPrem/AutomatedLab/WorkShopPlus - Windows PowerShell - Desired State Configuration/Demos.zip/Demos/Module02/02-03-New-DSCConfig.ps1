#Requires -RunAsAdministrator 
#Requires -Version 4
Clear-Host 
$CurrentDir = Split-Path -Path $MyInvocation.MyCommand.Path -Parent
#$CurrentDir="C:PShellDemos\Module02"

Set-Location -Path $CurrentDir

# Use CTRL+J to insert a configuration template


# Review the list of resources to find what you need
Get-DscResource -Module PSDesiredStateConfiguration | Out-GridView

# Get resource syntax. Copy/paste into configuration. Edit.
Get-DscResource Registry -Syntax



# Completed example
configuration SimpleConfig
{
	Import-DscResource -ModuleName PSDesiredStateConfiguration

	node localhost
	{
		Registry RegAssetOwner
		{
			Key = 'HKLM:\Software\Contoso\'
			ValueName = 'AssetOwner'
			Ensure = 'Present'
			ValueData = 'ericlang'
			ValueType = 'String'
		}
	}
}


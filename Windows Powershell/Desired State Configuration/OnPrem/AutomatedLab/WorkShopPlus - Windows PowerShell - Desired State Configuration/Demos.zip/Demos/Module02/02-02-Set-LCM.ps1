#Requires -RunAsAdministrator
Clear-Host 
$CurrentDir = Split-Path -Path $MyInvocation.MyCommand.Path -Parent
#$CurrentDir="C:PShellDemos\Module02"

Set-Location -Path $CurrentDir


# MetaConfig.mof
Get-ChildItem -Path C:\Windows\System32\Configuration\*meta*

Get-DscLocalConfigurationManager

# v5 PUSH
[DscLocalConfigurationManager()]
Configuration LCMPushv5
{
	Node localhost
	{
		Settings
		{
			ActionAfterReboot              = 'ContinueConfiguration'
			AllowModuleOverWrite           = $True
			ConfigurationMode              = 'ApplyAndAutoCorrect'
			ConfigurationModeFrequencyMins = 15
			RefreshFrequencyMins           = 30
			StatusRetentionTimeInDays      = 7
			RebootNodeIfNeeded             = $True
			RefreshMode                    = 'Push'
		}
	}
}
# Generating the MOF file(s)
LCMPushv5

# Setting the local LCM configuration
Set-DscLocalConfigurationManager -Path .\LCMPushv5

# Getting the local LCM configuration (for checking of the configuration was applied)
Get-DscLocalConfigurationManager


# Reset
Remove-Item -Path C:\windows\System32\Configuration\*meta*.mof

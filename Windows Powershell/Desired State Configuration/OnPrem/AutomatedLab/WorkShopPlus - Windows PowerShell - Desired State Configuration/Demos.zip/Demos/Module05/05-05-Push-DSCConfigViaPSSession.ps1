#Requires -RunAsAdministrator 
#Requires -Version 4
Clear-Host 
$CurrentDir = Split-Path -Path $MyInvocation.MyCommand.Path -Parent
#$CurrentDir="C:PShellDemos\Module05"

#To use TLS 1.2
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12

#Cleaning the community module installed locally
(Get-Module "[x]*" -ListAvailable).ModuleBase | Remove-Item -Recurse -Force -Verbose -ErrorAction Ignore

Set-Location -Path $CurrentDir

$node = 'ms1.contoso.com'

Install-Module -Name xRemoteDesktopAdmin -Verbose
Install-Module xNetworking -RequiredVersion '2.3.0.0' -Force -Verbose


$node = 'ms1.contoso.com'


#region Configuration using Resource Kit module


$ConfigData = @{
    AllNodes = @(
        @{
            NodeName = $node
            PSDscAllowPlainTextPassword = $true
         }
    )
}

Configuration AllowRemoteDesktopAdminConnections
{
param(
        [Parameter(Mandatory)] 
        [PSCredential]
        $Credential
    )
    
    Import-DscResource -Module PSDesiredStateConfiguration, xRemoteDesktopAdmin
    Import-DscResource -ModuleName @{ModuleName="xNetworking";RequiredVersion="2.3.0.0"}

    Node $AllNodes.NodeName
    {
        LocalConfigurationManager
        {
            RefreshMode = 'Push'
        }

        xRemoteDesktopAdmin RemoteDesktopSettings
        {
           Ensure = 'Present'
           UserAuthentication = 'Secure'
        }

        xFirewall AllowRDP
        {
            Name = 'DSC - Remote Desktop Admin Connections'
            DisplayGroup = "Remote Desktop"
            Ensure = 'Present'
            State = 'Enabled'
            Access = 'Allow'
            Profile = 'Domain'
        }

        Group RDPGroup
        {
           Ensure = 'Present'
           GroupName = 'Remote Desktop Users'
           Members = 'contoso\ericlang'
           Credential = $Credential
        }
         
    }
}

# Create MOF with configuration data
AllowRemoteDesktopAdminConnections -ConfigurationData $ConfigData `
    -Credential (Get-Credential -UserName contoso\ericlang -Message "Credentials to read AD users")

# Configure push mode
Set-DscLocalConfigurationManager .\AllowRemoteDesktopAdminConnections

# Apply the configuration
Start-DscConfiguration -Wait -Force -Verbose -Path .\AllowRemoteDesktopAdminConnections

# Notice error of missing resources

#endregion



#region Push resource modules manually

$Source = 'C:\Program Files\WindowsPowerShell\Modules\[xc]*'
$Dest   = 'C:\Program Files\WindowsPowerShell\Modules\'

$pss = New-PSSession $node
#Invoke-Command -Session $pss -ScriptBlock {del $using:Source -Confirm:$false -Recurse}


Copy-Item -Path $Source -ToSession $pss -Destination $Dest -Recurse -Force -Verbose
Invoke-Command -Session $pss -ScriptBlock {dir $using:Dest}
Invoke-Command -Session $pss -ScriptBlock {dir $using:Dest -Recurse}
Remove-PSSession $pss

#endregion



# Apply configuration with resources present

# Apply the configuration
Start-DscConfiguration -Wait -Force -Verbose -Path .\AllowRemoteDesktopAdminConnections

#endregion



### Reset demo ###


Invoke-Command -ComputerName $node -ScriptBlock {
    net localgroup "Remote Desktop Users" /delete contoso\ericlang
}

Remove-Item -Recurse -Force -Path .\AllowRemoteDesktopAdminConnections

$Dest   = "\\$node\C$\Program Files\WindowsPowerShell\Modules\"
Remove-Item "$Dest\[xc]*" -Recurse -Force


#Requires -RunAsAdministrator 
#Requires -Version 4
Clear-Host 
$CurrentDir = Split-Path -Path $MyInvocation.MyCommand.Path -Parent
#$CurrentDir="C:PShellDemos\Module05"

#To use TLS 1.2
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12

#Cleaning the community module installed locally
(Get-Module "[x]*" -ListAvailable).ModuleBase | Remove-Item -Recurse -Force -Verbose -ErrorAction Ignore

Set-Location -Path $CurrentDir

Install-Module -Name xPSDesiredStateConfiguration -Force -Verbose
#$CertificateThumbprint = (Get-ChildItem -Path Cert:\LocalMachine\My -SSLServerAuthentication | Select-Object -Last 1).Thumbprint
#$NewSelfSignedCertificate = New-SelfSignedCertificate -DnsName "$($Env:ComputerName).contoso.com" -CertStoreLocation cert:\LocalMachine\My
#$CertificateThumbprint = $NewSelfSignedCertificate.Thumbprint

$Certificate = Get-Certificate -Template 'WebServer5Years' -CertStoreLocation 'Cert:\LocalMachine\My' -SubjectName "CN=$($Env:ComputerName).contoso.com" -DnsName "$($Env:ComputerName).contoso.com" -Url ldap:



# Configuration for a simple PULL server, unencrypted HTTP
configuration CreateHTTPSPullServer
{
	param
	(
		[string[]]
		$ComputerName = 'localhost'
	)

	Import-DSCResource -ModuleName PSDesiredStateConfiguration
	# Update the module version appropriately
	Import-DSCResource -ModuleName xPSDesiredStateConfiguration

	Node $ComputerName
	{
		WindowsFeature DSCServiceFeature
		{
			Ensure = 'Present'
			Name   = 'DSC-Service'
		}
		xDscWebService PSDSCPullServer
		{
			Ensure                  = 'Present'
			EndpointName            = 'PSDSCPullServer'
			Port                    = 443
			PhysicalPath            = "$env:SystemDrive\inetpub\wwwroot\PSDSCPullServer"
			CertificateThumbPrint   = $Certificate.Certificate.Thumbprint
			ModulePath              = "$env:PROGRAMFILES\WindowsPowerShell\DscService\Modules"
			ConfigurationPath       = "$env:PROGRAMFILES\WindowsPowerShell\DscService\Configuration"
			State                   = 'Started'
			DependsOn               = '[WindowsFeature]DSCServiceFeature'
			UseSecurityBestPractices = $false
		}
	}
}

# Build the MOF
CreateHTTPSPullServer -ComputerName $Env:ComputerName

# Apply the configuration.
Start-DscConfiguration .\CreateHTTPSPullServer -Wait -Verbose

# View the web service
Start-Process -FilePath "https://$($Env:ComputerName).contoso.com/PSDSCPullServer.svc"

# Notice DSC-Service under Windows PowerShell
Get-WindowsFeature | Where-Object -Property DisplayName -Like -Value '*PowerShell*'

# Optional IIS console
Install-WindowsFeature Web-Mgmt-Console

#Requires -RunAsAdministrator 
#Requires -Version 5
Clear-Host 
$CurrentDir = Split-Path -Path $MyInvocation.MyCommand.Path -Parent
#$CurrentDir="C:PShellDemos\Module05"

#To use TLS 1.2
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12

#Cleaning the community module installed locally
(Get-Module "[x]*" -ListAvailable).ModuleBase | Remove-Item -Recurse -Force -Verbose -ErrorAction Ignore

Set-Location -Path $CurrentDir

# Find-DscResource from the online PowerShell Gallery or other repository
# First time you will get the NuGet.exe install prompt

Find-DscResource

Find-DscResource -Repository PSGallery

Get-DscResource -Module xStorage | Format-List -Property *

Install-Module -Name xStorage -Verbose
Update-Module -Name xStorage -Verbose

Get-ChildItem -Path 'C:\Program Files\WindowsPowerShell\Modules\xStorage' -Recurse
Set-Location -Path 'C:\Program Files\WindowsPowerShell\Modules'

tree /f /a
#Requires -RunAsAdministrator 
#Requires -Version 4
Clear-Host 
$CurrentDir = Split-Path -Path $MyInvocation.MyCommand.Path -Parent
#$CurrentDir="C:PShellDemos\Module01"

Set-Location -Path $CurrentDir

# Get-DscResource

Get-DscResource

Get-DscResource Group -Syntax


# Get the built-in resources
$BuiltInDSCResource = Get-DscResource -Module PSDesiredStateConfiguration
$BuiltInDSCResource

# List all built-in resources with properties
$BuiltInDSCResource | ForEach-Object -Process {
	$_.Name
	$_ |
	Select-Object -ExpandProperty Properties |
	Format-Table -AutoSize
}


#Requires -RunAsAdministrator 
#Requires -Version 4
Clear-Host 
$CurrentDir = Split-Path -Path $MyInvocation.MyCommand.Path -Parent
#$CurrentDir="C:PShellDemos\Module05"

#To use TLS 1.2
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12

#Cleaning the community module installed locally
(Get-Module "[x]*" -ListAvailable).ModuleBase | Remove-Item -Recurse -Force -Verbose -ErrorAction Ignore

Set-Location -Path $CurrentDir

$node = 'ms1.contoso.com'

Install-Module -Name xRemoteDesktopAdmin -Verbose
Install-Module xNetworking -RequiredVersion '2.3.0.0' -Force -Verbose

#region Configuration using Resource Kit module


$ConfigData = @{
    AllNodes = @(
        @{
            NodeName = $node
            PSDscAllowPlainTextPassword = $true
         }
    )
}

Configuration AllowRemoteDesktopAdminConnections
{
param(
        [Parameter(Mandatory)] 
        [PSCredential]
        $Credential
    )
    
    Import-DscResource -Module PSDesiredStateConfiguration, xRemoteDesktopAdmin
    Import-DscResource -ModuleName @{ModuleName="xNetworking";RequiredVersion="2.3.0.0"}

    Node $AllNodes.NodeName
    {
        LocalConfigurationManager
        {
            RefreshMode = 'Push'
        }

        xRemoteDesktopAdmin RemoteDesktopSettings
        {
           Ensure = 'Present'
           UserAuthentication = 'Secure'
        }

        xFirewall AllowRDP
        {
            Name = 'DSC - Remote Desktop Admin Connections'
            DisplayGroup = "Remote Desktop"
            Ensure = 'Present'
            State = 'Enabled'
            Access = 'Allow'
            Profile = 'Domain'
        }

        Group RDPGroup
        {
           Ensure = 'Present'
           GroupName = 'Remote Desktop Users'
           Members = 'contoso\ericlang'
           Credential = $Credential
        }
         
    }
}

$node | ForEach-Object { remove-Item "\\$_\C$\Program Files\WindowsPowerShell\Modules\[xc]*" -Recurse -Force -Verbose}

# Create MOF with configuration data
AllowRemoteDesktopAdminConnections -ConfigurationData $ConfigData `
    -Credential (Get-Credential -UserName contoso\ericlang -Message "Credentials to read AD users")

# Configure push mode
Set-DscLocalConfigurationManager .\AllowRemoteDesktopAdminConnections

# Apply the configuration
Start-DscConfiguration -Wait -Force -Verbose -Path .\AllowRemoteDesktopAdminConnections

# Notice error of missing resources

#endregion

#Removing the previously existing module on the target node if needed
$Dest   = "\\$node\C$\Program Files\WindowsPowerShell\Modules\"
Remove-Item "$Dest\[xc]*" -Recurse -Force

#region Push resource modules manually

# Later we can try this with the new "Copy-Item -FromSession -ToSession"
Invoke-Command -ComputerName $node -ScriptBlock {
    Get-NetFirewallRule FPS-SMB* | Enable-NetFirewallRule
}

$Source = 'C:\Program Files\WindowsPowerShell\Modules\[xc]*'
$Dest   = "\\$node\C$\Program Files\WindowsPowerShell\Modules\"

Get-ChildItem -Path $Source
Get-ChildItem -Path $Dest

Copy-Item -Path $Source -Destination $Dest -Recurse -ErrorAction SilentlyContinue

Get-ChildItem -Path $Dest

#endregion



# Apply configuration with resources present

# Apply the configuration
Start-DscConfiguration -Wait -Force -Verbose -Path .\AllowRemoteDesktopAdminConnections

#endregion

### Reset demo ###


Invoke-Command -ComputerName $node -ScriptBlock {
    net localgroup "Remote Desktop Users" /delete contoso\ericlang
}

Remove-Item -Recurse -Force -Path .\AllowRemoteDesktopAdminConnections

Remove-Item "$Dest\[xc]*" -Recurse -Force

﻿#Requires -RunAsAdministrator 
#Requires -Version 4
Clear-Host 
$CurrentDir = Split-Path -Path $MyInvocation.MyCommand.Path -Parent
#$CurrentDir="C:PShellDemos\Module05"

#To use TLS 1.2
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12

#Cleaning the community module installed locally
(Get-Module "[x]*" -ListAvailable).ModuleBase | Remove-Item -Recurse -Force -Verbose -ErrorAction Ignore

Set-Location -Path $CurrentDir
$ConfigName = "MyNewConfig"


#region Install the resource modules ##########################################

Install-Module xRemoteDesktopAdmin, xNetworking  -Force -Verbose
Install-Module xPSDesiredStateConfiguration -MaximumVersion 8.5.0.0 -Force -Verbose

#endregion ####################################################################



#region Configurations ########################################################

Configuration EnableRDP
{
	Param(
		[pscredential]$Credential
	)
	Import-DscResource -ModuleName PSDesiredStateConfiguration, xRemoteDesktopAdmin, xNetworking

	Node $AllNodes.NodeName
	{
		xRemoteDesktopAdmin RemoteDesktopSettings
		{
			Ensure = 'Present'
			UserAuthentication = 'Secure'
		}

		xFirewall AllowRDP
		{
			Name = 'DSC - Remote Desktop Admin Connections'
			Group = 'Remote Desktop'
			Ensure = 'Present'
			Enabled = $true
			Action = 'Allow'
			Profile = 'Domain'
		}

		Group RDPGroup
		{
			Ensure = 'Present'
			GroupName = 'Remote Desktop Users'
			Members = 'contoso\ericlang'
			Credential = $Credential
		}
	}
}

#endregion ####################################################################

#region LCM ###################################################################

[DSCLocalConfigurationManager()]
configuration LCMDecrypt
{
	Node $AllNodes.NodeName
	{
		Settings
		{
			ActionAfterReboot              = 'ContinueConfiguration'
			AllowModuleOverWrite           = $True
			ConfigurationMode              = 'ApplyAndMonitor'
			ConfigurationModeFrequencyMins = 15
			RefreshFrequencyMins           = 30
			StatusRetentionTimeInDays      = 7
			RebootNodeIfNeeded             = $True
			RefreshMode                    = 'Pull'
			CertificateID                  = $node.Thumbprint
			ConfigurationID                = $node.GUID
		}
		ConfigurationRepositoryWeb PullServer
		{
			ServerURL = 'https://PULL.contoso.com/PSDSCPullServer.svc'
			AllowUnsecureConnection  = $True
		}      
	}
}

#endregion ####################################################################



#region DYNAMIC CONFIGURATION DATA ############################################

$nodes = Import-Csv -Path C:\PublicKeys\index.csv | Where-Object { $_.Node -like "ms*"} 
$nodes | ForEach-Object { remove-Item "\\$($_.Node)\C$\Program Files\WindowsPowerShell\Modules\[xc]*" -Recurse -Force -Verbose}

$ConfigData = @{
	AllNodes = @(
		@{
			NodeName             = '*'
			PSDscAllowDomainUser = $true
		}
	)
}

ForEach ($node in $nodes) 
{
	$ConfigData.AllNodes += @{
		NodeName        = $node.Node
		CertificateFile = $node.Path
		Thumbprint      = $node.Thumbprint
		GUID            = $node.GUID
	}
}

$ConfigData.Values

#endregion ####################################################################



#region GENERATE MOF AND META.MOF #############################################

EnableRDP  -ConfigurationData $ConfigData -Credential (Get-Credential -UserName 'CONTOSO\Administrator' -Message 'Enter the password')

$MS1Guid = ($nodes | Where-Object { $_.Node -eq "ms1"}).GUID
$MS2Guid = ($nodes | Where-Object { $_.Node -eq "ms2"}).GUID
Move-Item -Path .\EnableRDP\ms1.mof -Destination ".\EnableRDP\$MS1Guid.mof" -Force
Move-Item -Path .\EnableRDP\ms2.mof -Destination ".\EnableRDP\$MS2Guid.mof" -Force


LCMDecrypt -ConfigurationData $ConfigData


Get-ChildItem -Path .\EnableRDP\*.mof  | ForEach-Object -Process {
	#psEdit -filenames $_.FullName
    $_.FullName
}
Get-ChildItem -Path .\LCMDecrypt\*.mof | ForEach-Object -Process {
	#psEdit -filenames $_.FullName
    $_.FullName
}

#endregion ####################################################################

Import-Module xPSDesiredStateConfiguration
Publish-DSCModuleAndMof -Source .\EnableRDP -ModuleNameList xRemoteDesktopAdmin, xNetworking  -Force
Get-ChildItem -Path 'C:\Program Files\WindowsPowerShell\DscService\Configuration\'

#Get-ChildItem -Path 'C:\Program Files\WindowsPowerShell\DscService\Configuration\' -File -Filter *.mof | ForEach-Object { New-DscChecksum -Path $($_.Fullname) -Verbose -Force }

# Getting the LCM Configuration on the targeted nodes
Get-DscLocalConfigurationManager -CimSession $Nodes.Node

# Setting the LCM Configuration on the targeted nodes
Set-DscLocalConfigurationManager -Path .\LCMDecrypt -Verbose -CimSession $Nodes.Node

# Getting the LCM Configuration on the targeted nodes
Get-DscLocalConfigurationManager -CimSession $Nodes.Node
(Get-DscLocalConfigurationManager -CimSession $Nodes.Node).ConfigurationDownloadManagers

# Forcing the configuration to refresh
Update-DscConfiguration -CimSession ms1 -Wait -Verbose
Update-DscConfiguration -CimSession ms2 -Wait -Verbose

Test-DscConfiguration -CimSession $Nodes.Node

# Testing if user is member of the local group
#Invoke-Command -ComputerName $Nodes.Node -ScriptBlock { net localgroup 'Remote Desktop Users' 'CONTOSO\ericlang' /delete}
Invoke-Command -ComputerName $Nodes.Node -ScriptBlock { Get-LocalGroupMember -Name 'Remote Desktop Users' }
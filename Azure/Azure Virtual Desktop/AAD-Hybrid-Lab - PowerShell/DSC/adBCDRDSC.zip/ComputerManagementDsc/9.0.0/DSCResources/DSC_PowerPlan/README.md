# Description

The resource allows specifying a power plan to activate.

configuration DomainController
{
    param
    (
        [Parameter(Mandatory)]
        [String]$ADDomainName,

        [Parameter(Mandatory)]
        [String]$CustomUPNSuffix,

        [Parameter(Mandatory)]
        [System.Management.Automation.PSCredential]$AdminCreds,

        [Parameter(Mandatory)]
        [Object]$usersArray,

        [Parameter(Mandatory)]
        [System.Management.Automation.PSCredential]$UserCreds
    )
   
    $shortDomain = $ADDomainName.Split('.')[0]
    
    [System.Management.Automation.PSCredential]$DomainCreds = New-Object System.Management.Automation.PSCredential ("$shortDomain\$($Admincreds.UserName)", $Admincreds.Password)
    
    $SecurePassword = $UserCreds.Password
    $ClearTextPassword = [Runtime.InteropServices.Marshal]::PtrToStringAuto([Runtime.InteropServices.Marshal]::SecureStringToBSTR($SecurePassword ))

    #Import-DscResource -ModuleName xActiveDirectory, xNetworking, xComputerManagement, PSDesiredStateConfiguration, xPendingReboot
    Import-DscResource -ModuleName ActiveDirectoryDSC, NetworkingDSC, ComputerManagementDSC, PSDesiredStateConfiguration
    
    $EthernetInterface = Get-NetAdapter | Where-Object -FilterScript { $_.InterfaceDescription -eq 'Microsoft Hyper-V Network Adapter'} | Sort-Object -Property Name | Select-Object -First 1

    $PublicDesktopPath = "C:\Users\Public\Desktop\"
    $links = @(
        @{site = "%windir%\system32\WindowsPowerShell\v1.0\PowerShell_ISE.exe"; name = "PowerShell ISE"; icon = "%SystemRoot%\system32\WindowsPowerShell\v1.0\powershell_ise.exe, 0" },
        @{site = "%SystemRoot%\system32\ServerManager.exe"; name = "Server Manager"; icon = "%SystemRoot%\system32\ServerManager.exe, 0" },
        @{site = "%SystemRoot%\system32\gpmc.msc"; name = "Group Policy Management"; icon = "%SystemRoot%\system32\gpoadmin.dll, 0" },
        @{site = "%SystemRoot%\system32\dsa.msc"; name = "AD Users and Computers"; icon = "%SystemRoot%\system32\dsadmin.dll, 0" },
        @{site = "%SystemRoot%\system32\domain.msc"; name = "AD Domains and Trusts"; icon = "%SystemRoot%\system32\domadmin.dll, 0" },
        @{site = "%SystemRoot%\system32\dnsmgmt.msc"; name = "DNS"; icon = "%SystemRoot%\system32\dnsmgr.dll, 0" },
        @{site = "%windir%\system32\services.msc"; name = "Services"; icon = "%windir%\system32\filemgmt.dll, 0" }
    )

    Node 'localhost'
    {
        LocalConfigurationManager {
            DebugMode          = 'All'
            RebootNodeIfNeeded = $true
        }

        Script SetDependencyforAzureGuestAgent{
            GetScript  = {
                $Result = [string](Get-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Services\WindowsAzureGuestAgent" -Name DependOnService -ErrorAction Ignore).DependOnService
                @{
                    GetScript  = $GetScript
                    SetScript  = $SetScript
                    TestScript = $TestScript
                    Result     = $Result
                }
            }
            SetScript  = { 
                Set-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Services\WindowsAzureGuestAgent" -Name DependOnService -Type MultiString -Value DNS
                Write-Verbose -Verbose "Changed dependency on Windows Azure Guest Agent to be dependent on DNS Server Service" 
            }
            TestScript = { 
                # Create and invoke a scriptblock using the $GetScript automatic variable, which contains a string representation of the GetScript.
                $state = [scriptblock]::Create($GetScript).Invoke()
                return $($state.Result -eq "DNS")
            }
        }

        WindowsFeature DNS { 
            Ensure = "Present" 
            Name   = "DNS"		
        }

        Script EnableDNSDiags {
            GetScript  = {
                $Result = (((Get-DnsServerDiagnostics).psobject.properties | Where-Object -FilterScript {$_.Name -notin @('LogFilePath', 'MaxMBFileSize', 'EventLogLevel', 'FilterIpAddrList', 'UseSystemEventLog', 'EnableLogFileRollover') -and $_.TypeNameOfValue -eq "bool"}) | Select-Object -Property Name, Value) | Out-String
                @{
                    GetScript  = $GetScript
                    SetScript  = $SetScript
                    TestScript = $TestScript
                    Result     = $Result
                }
            }
            SetScript  = { 
                Set-DnsServerDiagnostics -All $true
                Write-Verbose -Verbose "Enabling DNS client diagnostics" 
            }
            TestScript = { 
                # Create and invoke a scriptblock using the $GetScript automatic variable, which contains a string representation of the GetScript.
                $state = [scriptblock]::Create($GetScript).Invoke()
                return $($state.Result -notmatch [System.Boolean]::FalseString)
            }
            DependsOn  = "[WindowsFeature]DNS"
        }

        WindowsFeature DnsTools {
            Ensure    = "Present"
            Name      = "RSAT-DNS-Server"
            DependsOn = "[WindowsFeature]DNS"
        }

        DnsServerAddress DnsServerAddress { 
            Address        = '127.0.0.1' 
            InterfaceAlias = $EthernetInterface.Name
            AddressFamily  = 'IPv4'
            DependsOn      = "[WindowsFeature]DNS"
        }

        WindowsFeature ADDSInstall { 
            Ensure    = "Present" 
            Name      = "AD-Domain-Services"
            DependsOn = "[WindowsFeature]DNS" 
        } 

        WindowsFeature ADDSTools {
            Ensure    = "Present"
            Name      = "RSAT-ADDS-Tools"
            DependsOn = "[WindowsFeature]ADDSInstall"
        }

        WindowsFeature ADAdminCenter {
            Ensure    = "Present"
            Name      = "RSAT-AD-AdminCenter"
            DependsOn = "[WindowsFeature]ADDSInstall"
        }
         
        ADDomain FirstDS {
            DomainName                    = $ADDomainName
            Credential                    = $DomainCreds
            SafemodeAdministratorPassword = $DomainCreds
            DatabasePath                  = "C:\NTDS"
            LogPath                       = "C:\NTDS"
            SysvolPath                    = "C:\SYSVOL"
            DependsOn                     = "[WindowsFeature]ADDSInstall"
        } 

        #Sees if a reboot is required after installing the first DSC
        PendingReboot AfterFirstDS
        {
            Name      = "AfterFirstDS"
            DependsOn = '[ADDomain]FirstDS'
        }
        <#
        #>

        ADForestProperties Domainproperties {
            ForestName                   = $ADDomainName
            UserPrincipalNameSuffixToAdd = $CustomUPNSuffix
        }

        Script CreateAVDOU {
            GetScript  = {
                $Result = [string](Get-ADOrganizationalUnit -Server localhost -Filter 'Name -like "AVD"' -ErrorAction Ignore).DistinguishedName
                @{
                    GetScript  = $GetScript
                    SetScript  = $SetScript
                    TestScript = $TestScript
                    Result     = $Result
                }
            }
            SetScript  = {
                New-ADOrganizationalUnit -Name "AVD" -Path $((Get-ADRootDSE).defaultNamingContext)
            }
            TestScript = { 
                # Create and invoke a scriptblock using the $GetScript automatic variable, which contains a string representation of the GetScript.
                $state = [scriptblock]::Create($GetScript).Invoke()
                return -not([string]::IsNullOrEmpty($state.Result))
            }
            DependsOn = "[ADDomain]FirstDS"
        }

        Script CreateOrgUsersOU {
            GetScript  = {
                $Result = [string](Get-ADOrganizationalUnit -Server localhost -Filter 'Name -like "OrgUsers"' -ErrorAction Ignore).DistinguishedName
                @{
                    GetScript  = $GetScript
                    SetScript  = $SetScript
                    TestScript = $TestScript
                    Result     = $Result
                }
            }
            SetScript  = {
                New-ADOrganizationalUnit -Name "OrgUsers" -Path $((Get-ADRootDSE).defaultNamingContext)
            }
            TestScript = { 
                # Create and invoke a scriptblock using the $GetScript automatic variable, which contains a string representation of the GetScript.
                $state = [scriptblock]::Create($GetScript).Invoke()
                return -not([string]::IsNullOrEmpty($state.Result))
            }
            DependsOn = "[ADDomain]FirstDS"
        }


        Script AddTestUsers {
            GetScript  = {
                $OrgUsersOUDN = (Get-ADOrganizationalUnit -Server localhost -Filter 'Name -like "OrgUsers"' -ErrorAction Ignore).DistinguishedName
                $Result = Get-ADUser -SearchBase $OrgUsersOUDN -Filter * | Out-String
                @{
                    GetScript  = $GetScript
                    SetScript  = $SetScript
                    TestScript = $TestScript
                    Result     = $Result
                }
            }
            SetScript  = {
                $OU = (Get-ADOrganizationalUnit -Server localhost -Filter 'Name -like "OrgUsers"' -ErrorAction Ignore).DistinguishedName
                foreach ($User in $using:usersArray) {
                    $Displayname = $User.'FName' + " " + $User.'LName'
                    $UserFirstname = $User.'FName'
                    $UserLastname = $User.'LName'
                    $SAM = $User.'SAM'
                    $UPN = $User.'FName' + "." + $User.'LName' + "@" + $using:customupnsuffix
                    "$DisplayName, $using:ClearTextPassword, $SAM"
                    New-ADUser `
                        -Name "$Displayname" `
                        -DisplayName "$Displayname" `
                        -SamAccountName $SAM `
                        -UserPrincipalName $UPN `
                        -GivenName "$UserFirstname" `
                        -Surname "$UserLastname" `
                        -Description "$Description" `
                        -AccountPassword (ConvertTo-SecureString $using:ClearTextPassword -AsPlainText -Force) `
                        -Enabled $true `
                        -Path "$OU" `
                        -ChangePasswordAtLogon $false `
                        -PasswordNeverExpires $true `
                        -EmailAddress $UPN
                }
            }

            TestScript = { 
                $OU = (Get-ADOrganizationalUnit -Server localhost -Filter 'Name -like "OrgUsers"' -ErrorAction Ignore).DistinguishedName
                $SamAccountName = (Get-ADUser -Filter * -SearchBase $OU).SamAccountName
                $Result = $true
                foreach ($CurrentUser in $using:usersArray)
                {
                    $Result = $Result -and $($CurrentUser.SAM -in $SamAccountName)
                    if (-not($result))
                    {
                        break
                    }
                }
                return $Result
            }
            DependsOn  = '[Script]CreateOrgUsersOU'
        }

        ADGroup 'AVDUsersADGroup'
        {
            GroupName   = 'AVD Users'
            GroupScope  = 'Global'
            Category    = 'Security'
            Description = 'AVD Users'
            Ensure      = 'Present'
            Path        = "OU=OrgUsers,DC={0}" -f $($ADDomainName.replace(".", ",DC="))
            Members     = $usersArray.SAM
            DependsOn  = '[Script]AddTestUsers'
        }
        
        Script AddRemoveTeamsAutostartGPO {
            GetScript  = {
                $Result = Get-GPO -Name "C-TeamsNoAutostart" -ErrorAction Ignore | Out-String
                @{
                    GetScript  = $GetScript
                    SetScript  = $SetScript
                    TestScript = $TestScript
                    Result     = $Result
                }
            }
            SetScript  = {
                Write-Host 'Create and link GPO to disable Teams autostart after Install'
                New-GPO -Name "C-TeamsNoAutostart"
                Set-GPPrefRegistryValue -Name "C-TeamsNoAutostart" -Context Computer -Key "HKLM\SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Run" -ValueName "Teams" -Value "" -Type String -Action Delete
                New-GPLink -Name "C-TeamsNoAutostart" -Target $((Get-ADRootDSE).defaultNamingContext)
                Write-Host 'Completed GPO creation'
            }

            TestScript = { 
                # Create and invoke a scriptblock using the $GetScript automatic variable, which contains a string representation of the GetScript.
                $state = [scriptblock]::Create($GetScript).Invoke()
                return -not([string]::IsNullOrEmpty($state.Result))
            }
            DependsOn = "[ADDomain]FirstDS"
        }

        Script InstallAADConnect {
            
            GetScript  = {
                $Result = [string](Get-Package -Name "Microsoft Entra Connect Sync" -ErrorAction Ignore | Out-String)
                @{
                    GetScript  = $GetScript
                    SetScript  = $SetScript
                    TestScript = $TestScript
                    Result     = $Result
                }
            }
            SetScript  = {
                $AADConnectDLUrl = "https://download.msappproxy.net/Subscription/d3c8b69d-6bf7-42be-a529-3fe9c2e70c90/Connector/AADConnectSyncInstaller"
                #Start-BitsTransfer $AADConnectDLUrl -Destination $env:TEMP\AzureADConnect.msi -HttpMethod Get -Verbose
                Invoke-RestMethod -Uri $AADConnectDLUrl -OutFile $env:TEMP\AzureADConnect.msi -Verbose
                Start-Process -FilePath "$env:comspec" -ArgumentList "/c", "$env:TEMP\AzureADConnect.msi /qn /passive /forcerestart" -Wait
            }
            TestScript = { 
                # Create and invoke a scriptblock using the $GetScript automatic variable, which contains a string representation of the GetScript.
                $state = [scriptblock]::Create($GetScript).Invoke()
                return -not([string]::IsNullOrEmpty($state.Result))
            }
        }

        Script Shortcuts {
            GetScript  = {
                $Result = (Get-ChildItem -Path C:\Users\Public\Desktop\*.lnk -Include $($link.name)).Name | Out-string
                @{
                    GetScript  = $GetScript
                    SetScript  = $SetScript
                    TestScript = $TestScript
                    Result     = $Result
                }
            }

            SetScript  = {   
                $WshShell = New-Object -comObject WScript.Shell

                foreach ($CurrentLinkName in $using:links) {
                    $Shortcut = $WshShell.CreateShortcut("$($using:PublicDesktopPath)$($CurrentLinkName.name).lnk")
                    $Shortcut.TargetPath = $CurrentLinkName.site
                    $Shortcut.IconLocation = $CurrentLinkName.icon
                    $Shortcut.Save()
                }
            }
            TestScript = { 
                $DesktopLinkBaseName = (Get-ChildItem -Path C:\Users\Public\Desktop\*.lnk -Include $($link.name)).BaseName
                $Result = $true
                foreach ($CurrentLinkName in $using:links.name)
                {
                    $Result = $Result -and $($CurrentLinkName -in $DesktopLinkBaseName)
                    if (-not($result))
                    {
                        break
                    }
                }
                return $Result
            }
        }

        Script EnableTLS12 {
            GetScript  = {
                $Result = [string](Get-ItemProperty -Path 'HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\TLS 1.2\Server' -Name Enabled).Enabled
                @{
                    GetScript  = $GetScript
                    SetScript  = $SetScript
                    TestScript = $TestScript
                    Result     = $Result
                }
            }

            SetScript  = {
                $null = New-Item 'HKLM:\SOFTWARE\WOW6432Node\Microsoft\.NETFramework\v4.0.30319' -Force
                $null = New-ItemProperty -path 'HKLM:\SOFTWARE\WOW6432Node\Microsoft\.NETFramework\v4.0.30319' -name 'SystemDefaultTlsVersions' -value '1' -PropertyType 'DWord' -Force
                $null = New-ItemProperty -path 'HKLM:\SOFTWARE\WOW6432Node\Microsoft\.NETFramework\v4.0.30319' -name 'SchUseStrongCrypto' -value '1' -PropertyType 'DWord' -Force
                $null = New-Item 'HKLM:\SOFTWARE\Microsoft\.NETFramework\v4.0.30319' -Force
                $null = New-ItemProperty -path 'HKLM:\SOFTWARE\Microsoft\.NETFramework\v4.0.30319' -name 'SystemDefaultTlsVersions' -value '1' -PropertyType 'DWord' -Force
                $null = New-ItemProperty -path 'HKLM:\SOFTWARE\Microsoft\.NETFramework\v4.0.30319' -name 'SchUseStrongCrypto' -value '1' -PropertyType 'DWord' -Force
                $null = New-Item 'HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\TLS 1.2\Server' -Force
                $null = New-ItemProperty -path 'HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\TLS 1.2\Server' -name 'Enabled' -value '1' -PropertyType 'DWord' -Force
                $null = New-ItemProperty -path 'HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\TLS 1.2\Server' -name 'DisabledByDefault' -value 0 -PropertyType 'DWord' -Force
                $null = New-Item 'HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\TLS 1.2\Client' -Force
                $null = New-ItemProperty -path 'HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\TLS 1.2\Client' -name 'Enabled' -value '1' -PropertyType 'DWord' -Force
                $null = New-ItemProperty -path 'HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\TLS 1.2\Client' -name 'DisabledByDefault' -value 0 -PropertyType 'DWord' -Force
                Write-Host 'TLS 1.2 has been enabled.'
            }

            TestScript = { 
                # Create and invoke a scriptblock using the $GetScript automatic variable, which contains a string representation of the GetScript.
                $state = [scriptblock]::Create($GetScript).Invoke()
                return $("1" -eq $state.Result)
            }
        }

	    Script InstallPowerShellCrossPlatform {
            GetScript  = {
                @{
                    GetScript = $GetScript
                    SetScript = $SetScript
                    TestScript = $TestScript
                }
            }
 
            SetScript  = {
                Invoke-Expression -Command "& { $(Invoke-RestMethod https://aka.ms/install-powershell.ps1) } -UseMSI -Quiet"
            }
 
            TestScript = {
                return ($null -ne (Get-ChildItem -Path $env:ProgramFiles -Filter pwsh.exe -Recurse -File -ErrorAction SilentlyContinue))
            }
        }

	    Script InstallVSCode {
            GetScript  = {
                @{
                    GetScript  = $GetScript
                    SetScript  = $SetScript
                    TestScript = $TestScript
                }
            }
 
            SetScript  = {
                #Variables below are needed by the Install-VSCode.ps1 in this script DSC ressource (Not needed in a normal call)
                $IsLinux   = $false
                $IsMacOS   = $false
                $IsWindows = $true
                $pacMan    = ''
                #try is necessary because the addition extensions raised some errors for the moment :code.cmd : (node:4812) [DEP0005] DeprecationWarning: Buffer() is deprecated due to security and usability issues. Please use the Buffer.alloc(), Buffer.allocUnsafe(), or Buffer.from() methods instead.
                try
                {
                    Invoke-Expression -Command "& { $(Invoke-RestMethod https://raw.githubusercontent.com/PowerShell/vscode-powershell/master/scripts/Install-VSCode.ps1) }" -ErrorAction Ignore -Verbose *>&1 | Out-File C:\Install-VSCode.log -Append
                } catch {}
            }
 
            TestScript = {
                return ($null -ne (Get-ChildItem -Path $env:ProgramFiles -Filter Code.exe -Recurse -File -ErrorAction SilentlyContinue))
            }
            DependsOn  = @("[Script]InstallPowerShellCrossPlatform")
            Credential = $DomainCreds # Credential to join to domain
        }
    }
}

<#
#region Example #1
Clear-Host
$Error.Clear()
Get-PackageProvider -Name NuGet -Force -Verbose
Install-Module -Name ActiveDirectoryDSC, NetworkingDSC, ComputerManagementDSC -Force -Verbose

$CurrentScript = $MyInvocation.MyCommand.Path
#Getting the current directory (where this script file resides)
$CurrentDir = Split-Path -Path $CurrentScript -Parent
Set-Location -Path $CurrentDir 

$AdminCredential = Get-Credential -Credential $env:USERNAME
$UserCredential  = Get-Credential -Credential "Only password is required"
$UserArray = @(
    @{"FName" = "Bob";   "LName" = "Jones";    "SAM" = "bjones" }
    @{"FName" = "Bill";  "LName" = "Smith";    "SAM" = "bsmith" }
    @{"FName" = "Mary";  "LName" = "Phillips"; "SAM" = "mphillips" }
    @{"FName" = "Sue";   "LName" = "Jackson";  "SAM" = "sjackson" }
    @{"FName" = "Jack";  "LName" = "Petersen"; "SAM" = "jpetersen" }
    @{"FName" = "Julia"; "LName" = "Williams"; "SAM" = "jwilliams" }
)


$ConfigurationData = @{
    AllNodes = @(
        @{
            NodeName                    = 'localhost'
            PSDscAllowDomainUser        = $true
            PSDscAllowPlainTextPassword = $true
        }
    )
}

$Parameters = @{
    "usersArray"        = $UserArray
    "ADDomainName"      = "csa.fr"
    "CustomUPNSuffix"   = "cloudsolutionarchitect.fr"
    "AdminCreds"        = $AdminCredential
    "UserCreds"         = $UserCredential
    "ConfigurationData" = $ConfigurationData
}


DomainController @Parameters
Start-DscConfiguration -Path .\DomainController -Wait -Force -Verbose #-Debug
#endregion
#>
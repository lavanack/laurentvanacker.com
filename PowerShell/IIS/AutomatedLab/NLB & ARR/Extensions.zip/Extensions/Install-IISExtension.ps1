﻿#requires -version 5
#Clear-Host
Import-Module DISM

$CurrentDir=Split-Path -Path $MyInvocation.MyCommand.Path -Parent
$TimeStamp = '{0:yyyyMMddTHHmmss}' -f (Get-Date)
$BaseName = (Get-Item ($MyInvocation.MyCommand.Path)).BaseName
$LogDir="$env:WINDIR\Temp\Logs\$env:COMPUTERNAME"
$null=New-Item -Path "$LogDir\Archives" -Type Directory -Force

Function Install-IISExtension
{
    [CmdletBinding()]
    Param(
		[parameter(Mandatory = $true)]
        [PSObject]$Data,

		[parameter(Mandatory = $true)]
        [string]$LogDir
    )

    $Filter="Name like '"+$($Data.Name)+"'"
    $CurrentLogFile=(Join-Path -Path $LogDir -ChildPath (Get-Item $Data.MSI).Name) -replace ".msi$", ".log"

    If ((Get-CimInstance Win32_Product -Filter $Filter) -eq $null)
    {
        Write-Host "Installing $($Data.Name)"
        Start-Process -FilePath "msiexec" -ArgumentList "/package `"$($Data.MSI)`" /passive /log `"$CurrentLogFile`"" -Wait -NoNewWindow


        If ((Get-CimInstance Win32_Product -Filter $Filter) -ne $null)
        {
            Write-Host "[OK] $($Data.Name) was successfully installed on the system ..."            
        }
        else
        {
            Write-Host "[ERROR] $($Data.Name) was NOT successfully installed on the system ..."            
        }
    }
    else
    {
        Write-Host "$($Data.Name) is already installed on the system ..."            
    }
}

$URLRewriteData = New-Object -TypeName PSObject -Property @{Name="IIS URL Rewrite Module 2"; MSI="$CurrentDir\rewrite_amd64_en-US.msi";InstallationFolder=$null}
$ARRData = New-Object -TypeName PSObject -Property @{Name="Microsoft Application Request Routing 3.0"; MSI="$CurrentDir\requestRouter_amd64.msi";InstallationFolder=$null}
$ExternalCacheData = New-Object -TypeName PSObject -Property @{Name="Microsoft External Cache"; MSI="$CurrentDir\ExternalDiskCache_amd64.msi";InstallationFolder=$null}
$WebDeployData = New-Object -TypeName PSObject -Property @{Name="Microsoft Web Deploy 3.6"; MSI="$CurrentDir\WebDeploy_amd64_en-US.msi";InstallationFolder=$null}
$LogParserData = New-Object -TypeName PSObject -Property @{Name="Log Parser 2.2"; MSI="$CurrentDir\LogParser.msi";InstallationFolder=$null}

Install-IISExtension -Data $URLRewriteData -LogDir $LogDir
Install-IISExtension -Data $ARRData -LogDir $LogDir
Install-IISExtension -Data $ExternalCacheData -LogDir $LogDir
Install-IISExtension -Data $WebDeployData -LogDir $LogDir
Install-IISExtension -Data $LogParserData -LogDir $LogDir
